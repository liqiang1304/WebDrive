﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System.SDModule
{
    /// <summary>
    /// ViewInvoiceDialog.xaml 的互動邏輯
    /// </summary>
    public partial class ViewInvoiceDialog : Window
    {
        public ViewInvoiceDialog()
        {
            InitializeComponent();
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {

            ERP_System.ERP_DBDataSet eRP_DBDataSet = ((ERP_System.ERP_DBDataSet)(this.FindResource("eRP_DBDataSet")));
            // 将数据加载到表 invoice 中。可以根据需要修改此代码。
            ERP_System.ERP_DBDataSetTableAdapters.invoiceTableAdapter eRP_DBDataSetinvoiceTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.invoiceTableAdapter();
            eRP_DBDataSetinvoiceTableAdapter.Fill(eRP_DBDataSet.invoice);
            System.Windows.Data.CollectionViewSource invoiceViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("invoiceViewSource")));
            invoiceViewSource.View.MoveCurrentToFirst();
        }
    }
}
