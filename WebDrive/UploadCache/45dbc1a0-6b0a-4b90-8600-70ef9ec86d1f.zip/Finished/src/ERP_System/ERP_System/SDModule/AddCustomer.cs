﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.SDModule
{
    class AddCustomer
    {
        private ERP_DBEntities db = new ERP_DBEntities();

        public int add(String companyCode, String name, String address, String texRate, String country)
        {
            CheckTextBox checkTextBox = new CheckTextBox();
            if (!checkTextBox.checkIsNum(companyCode) || checkTextBox.checkIsNull(name)
              || checkTextBox.checkIsNull(address) || !checkTextBox.checkIsDecimal(texRate)
              || checkTextBox.checkIsNull(country))
            {
                return 1;
            }

            customers customer_Insert = new customers
            {
                companyCode = int.Parse(companyCode),
                name = name,
                address = address,
                texRate = decimal.Parse(texRate),
                country = country
            };

            try
            {
                //to new a new customer.
                Console.WriteLine(customer_Insert.texRate);
                db.customers.Add(customer_Insert);
                db.SaveChanges();
                //MessageBox.Show("已新增客户：" + CompanyNameTextBox.Text.ToString(), "新增客户成功！", MessageBoxButton.OK, MessageBoxImage.Information);

                customer_Insert = null;

            }
            catch
            {
                db.customers.Remove(customer_Insert);
                //MessageBox.Show("数据库写入异常！", "新增客户失败！", MessageBoxButton.OK, MessageBoxImage.Information);
                return 2;
                //if insert db error then info.
            }


            return 0;
        }
    }
}
