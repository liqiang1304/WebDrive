﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System.SDModule
{
    /// <summary>
    /// NewDeliveryDialog.xaml 的互動邏輯
    /// </summary>
    public partial class NewDeliveryDialog : Window
    {
        private int getDeliveryID;
        private ERP_DBEntities db = new ERP_DBEntities();

        public NewDeliveryDialog(int deliveryID)
        {
            InitializeComponent();
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
            DeliveryIDTextBox.Text = deliveryID.ToString();
            getDeliveryID = deliveryID;
            //init

            var findDeliveryIDQuery = from d in db.deliveryOrder where d.deliveryOrderID == getDeliveryID select d.deliveryOrderID;
            if (findDeliveryIDQuery.ToList().Count() != 0)
            {
                MessageBox.Show("递送单号重复！请检查！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            //find is ID repeat?
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {

            ERP_System.ERP_DBDataSet eRP_DBDataSet = ((ERP_System.ERP_DBDataSet)(this.FindResource("eRP_DBDataSet")));
            // 将数据加载到表 salesOrder 中。可以根据需要修改此代码。
            ERP_System.ERP_DBDataSetTableAdapters.salesOrderTableAdapter eRP_DBDataSetsalesOrderTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.salesOrderTableAdapter();
            eRP_DBDataSetsalesOrderTableAdapter.Fill(eRP_DBDataSet.salesOrder);
            System.Windows.Data.CollectionViewSource salesOrderViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("salesOrderViewSource")));
            salesOrderViewSource.View.MoveCurrentToFirst();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            CheckTextBox checkTextBox = new CheckTextBox();
            var selectRow = (System.Data.DataRowView)salesOrderDataGrid.SelectedItem;
            int selectSalesID = -1;
            try
            {
                selectSalesID = (int)selectRow["salesOrderID"];
            }
            catch
            {
                MessageBox.Show("请选择订单发货！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (checkTextBox.checkIsNull(LocationTextBox.Text) || DeliveryDataDatePicker.DisplayDate == null)
            {
                MessageBox.Show("输入信息有误！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            //input check

            var selectCompanyCode = from d in db.salesOrder where d.salesOrderID == selectSalesID select d.companyCode;
            int getCompanyCode = int.Parse(selectCompanyCode.First().ToString());

            var findRepeatSalesOrderID = from d in db.deliveryOrder where d.salesOrder == selectSalesID select d.salesOrder;

            if (isStockEnough(selectSalesID) == false)
            {
                MessageBox.Show("货物不足！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
                //find is goods enough?
            else
            {
                if (minusStock(selectSalesID) == false)
                {

                    MessageBox.Show("数据库读写错误！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
            }

            if (findRepeatSalesOrderID.ToList().Count() != 0)
            {
                MessageBox.Show("此订货单已发货！请重新选择！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            //find sales ID is repeat?

            deliveryOrder addDeliveryOrder = new deliveryOrder()
            {
                companyCode = getCompanyCode,
                deliveryOrderID = getDeliveryID,
                salesOrder = selectSalesID,
                deliveryLocation = LocationTextBox.Text,
                deliveryDate = DeliveryDataDatePicker.DisplayDate
            };
            try
            {
                db.deliveryOrder.Add(addDeliveryOrder);
                db.SaveChanges();

                //wirte to db and catch some error!
            }
            catch
            {
                db.deliveryOrder.Remove(addDeliveryOrder);
                MessageBox.Show("数据库读写错误！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            this.Close();
        }

        private bool isStockEnough(int salesID)
        {
            //find stock is enough?
            var findMaterialQuery = from d in db.sales_ma where d.salesOrderID == salesID select d;
            foreach (sales_ma slaes_material  in findMaterialQuery.ToList())
            {
                var findMaterialEnough = from b in db.materials where b.materialID == slaes_material.materialID select b.stock;
                int MaterialInStock = (int)findMaterialEnough.First();
                if (MaterialInStock < slaes_material.materialAmount)
                    return false;
            }
            return true;
        }

        private bool minusStock(int salesID)
        {
            //after delivery, minus goods in the stock
            var findMaterialQuery = from d in db.sales_ma where d.salesOrderID == salesID select d;
            foreach (sales_ma slaes_material in findMaterialQuery.ToList())
            {
                materials findMaterialAmount = db.materials.First(c=>c.materialID == slaes_material.materialID);
                findMaterialAmount.stock = findMaterialAmount.stock - slaes_material.materialAmount;
            }
            try
            {
                db.SaveChanges();
            }
            catch
            {
                return false;
            }
            return true;
        }
    }
}
