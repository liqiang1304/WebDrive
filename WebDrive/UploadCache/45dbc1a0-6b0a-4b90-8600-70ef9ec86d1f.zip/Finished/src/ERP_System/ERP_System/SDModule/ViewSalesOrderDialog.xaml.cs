﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System.SDModule
{
    /// <summary>
    /// ViewSalesOrderDialog.xaml 的互動邏輯
    /// </summary>
    public partial class ViewSalesOrderDialog : Window
    {
        public ViewSalesOrderDialog()
        {
            InitializeComponent();
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {

            ERP_System.ERP_DBDataSet eRP_DBDataSet = ((ERP_System.ERP_DBDataSet)(this.FindResource("eRP_DBDataSet")));
            // 将数据加载到表 salesOrder 中。可以根据需要修改此代码。
            ERP_System.ERP_DBDataSetTableAdapters.salesOrderTableAdapter eRP_DBDataSetsalesOrderTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.salesOrderTableAdapter();
            eRP_DBDataSetsalesOrderTableAdapter.Fill(eRP_DBDataSet.salesOrder);
            System.Windows.Data.CollectionViewSource salesOrderViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("salesOrderViewSource")));
            salesOrderViewSource.View.MoveCurrentToFirst();
            // 将数据加载到表 sales_ma 中。可以根据需要修改此代码。
            //ERP_System.ERP_DBDataSetTableAdapters.sales_maTableAdapter eRP_DBDataSetsales_maTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.sales_maTableAdapter();
           // eRP_DBDataSetsales_maTableAdapter.Fill(eRP_DBDataSet.sales_ma);
            //System.Windows.Data.CollectionViewSource sales_maViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("sales_maViewSource")));
            //sales_maViewSource.View.MoveCurrentToFirst();
        }

        private void salesOrderDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectSalesOrder = (System.Data.DataRowView)salesOrderDataGrid.SelectedItem;
            int salesOrderID = (int)selectSalesOrder["salesOrderID"];

            ERP_System.ERP_DBDataSet eRP_DBDataSet = ((ERP_System.ERP_DBDataSet)(this.FindResource("eRP_DBDataSet")));

            ERP_System.ERP_DBDataSetTableAdapters.sales_maTableAdapter eRP_DBDataSetsales_maTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.sales_maTableAdapter();
            //eRP_DBDataSetsales_maTableAdapter.Fill(eRP_DBDataSet.sales_ma);
            eRP_DBDataSetsales_maTableAdapter.FillBySalesOrderID(eRP_DBDataSet.sales_ma,salesOrderID);
            System.Windows.Data.CollectionViewSource sales_maViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("sales_maViewSource")));
            sales_maViewSource.View.MoveCurrentToFirst();

        }
    }
}
