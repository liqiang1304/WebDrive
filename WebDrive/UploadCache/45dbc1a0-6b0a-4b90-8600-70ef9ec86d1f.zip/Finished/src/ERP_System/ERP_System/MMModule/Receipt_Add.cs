﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.MMModule
{
    class Receipt_Add
    {
        private Db_Operate DataBase_Operate; //db related var.
        private receipt Receipt;
        private materials Materials;
        public Receipt_Add()
        {
            DataBase_Operate = new Db_Operate();
            //init db operator
        }

        public List<string> GetOrderFormID()
        {
            //get orderform id
            return DataBase_Operate.OrderForm_GetOrderFormID();
        }
        public List<string> GetSelectedFormInfo(int selected)
        {
            return DataBase_Operate.OrderForm_GetSelectedOrderFormInfo(selected);
        }
        public void Set(int VendorCode,int ReceiptID,DateTime CurrentTime,int Amount,int Quantity,int MaterialsID)
        {
            Receipt = new receipt()
            {
                vendorCode = VendorCode,
                receiptID = ReceiptID,
                creationDate = CurrentTime,
                amount = Amount
            };
            //new a class

            Materials = new materials()
            {
                quantity = Quantity,
                materialID = MaterialsID
            };




        }

        public void Add()
        {
            DataBase_Operate.Receipt_NewReceipt(Receipt);
            DataBase_Operate.Materials_AddSelectedMaterialsStock(Materials);
        }
    }
}
