﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.SDModule
{
    class CheckTextBox
    {
        public bool checkIsNull(String context)
        {
            if(context == "")
                return true;
            else
            {
                Console.WriteLine(context);
                return false;
                //check input is null or not? if this null then return true;
            }
        }

        public bool checkIsNum(String context)
        {
            int integer;
            try
            {
                integer = int.Parse(context);
            }
            catch
            {
                Console.WriteLine(context);
                return false;
                //check input is number or not? if it's number reutrn true;
            }
            return true;
        }

        public bool checkIsDecimal(String context)
        {
            Decimal dec;
            try
            {
                dec = Decimal.Parse(context);
            }
            catch
            {
                Console.WriteLine(context);
                return false;
                //check input is decimal or not? if it's then return true;
            }
            return true;
        }


    }
}
