﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.MMModule
{
    class OrderForm_Check
    {
        private Db_Operate DataBase_Operate; //db related var.
        public OrderForm_Check()
        {
            DataBase_Operate = new Db_Operate();
        }

        public List<string> GetSelectedOrderFormInfo(int selected)
        {
            //get selected orderfrom table infomation
            return DataBase_Operate.OrderForm_GetSelectedOrderFormInfo(selected);
        
        }

        public List<string> GetOrderFormID()
        {
            //get order formID
            return DataBase_Operate.OrderForm_GetOrderFormID();
        }
    }
}
