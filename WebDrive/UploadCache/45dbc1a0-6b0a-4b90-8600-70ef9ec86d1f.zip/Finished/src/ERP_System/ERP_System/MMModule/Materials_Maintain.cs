﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.MMModule
{
    class Materials_Maintain
    {
        private Db_Operate DataBase_Operate; //db related var.

        public Materials_Maintain()
        {
            DataBase_Operate = new Db_Operate();
        }

        public void Maintain()
        {

        }

        public List<string> GetSelectedVendorName(string Selected)
        {
            //get selected vendor name
            return DataBase_Operate.Materials_GetSelectedVendorName(Selected);
        }

        public materials GetSelectedUnitPrice(string Selected,int comboxindex)
        {
            //get selected unit price
            return DataBase_Operate.Materials_GetSelectedUnitPrice(Selected,comboxindex);
        }

        public void ChangeSelectedUnitPrice(string namecombox, int vendorcombox, decimal unitprice)
        {
            //cahgne selected unit price 
            DataBase_Operate.Materials_ChangeSelectedUnitPrice(namecombox, vendorcombox, unitprice);
        }

        public List<string> GetMaterialsName()
        {
            return DataBase_Operate.Materials_GetMaterialsName();
        }
    }
}
