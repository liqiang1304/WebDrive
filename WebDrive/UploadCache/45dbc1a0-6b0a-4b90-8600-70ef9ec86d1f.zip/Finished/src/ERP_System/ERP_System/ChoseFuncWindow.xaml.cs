﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System
{
    /// <summary>
    /// ChoseFuncWindow.xaml 的互動邏輯
    /// </summary>
    public partial class ChoseFuncWindow : Window
    {

        private String UsernameStr;
        private String PasswordStr;
        private ERP_DBEntities db;

        public ChoseFuncWindow(String username, String password)
        {
            InitializeComponent();
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
            UsernameStr = username;
            PasswordStr = password;

            ImageBrush b = new ImageBrush();
            b.ImageSource = new BitmapImage(new Uri("pack://application:,,,/ChoseFuncBackground.jpg"));
            b.Stretch = Stretch.Fill;
            this.Background = b;
        }

        private void SDButton_Click(object sender, RoutedEventArgs e)
        {
            SDModule.SDWindow sdWindow = new SDModule.SDWindow();
            //sdWindow.Show();
            sdWindow.ShowDialog();

        }

        private void MMButton_Click(object sender, RoutedEventArgs e)
        {
            MMModule.MMWindow mmWindow = new MMModule.MMWindow();
            //mmWindow.Show();
            mmWindow.ShowDialog();
        }

        private void InformationButton_Click(object sender, RoutedEventArgs e)
        {
            InfoModule.ModifyInfoWindow modifyInfoWindow = new InfoModule.ModifyInfoWindow(UsernameStr, PasswordStr);
            //modifyInfoWindow.Show();
            modifyInfoWindow.ShowDialog();
        }

        private void ManageButton_Click(object sender, RoutedEventArgs e)
        {
            // check if user is super user
            db = new ERP_DBEntities();
            var Users = from d in db.user where ((d.Username == UsernameStr) && (d.Password == PasswordStr)) select d.Type;
            Boolean isSuperUser = false;
            // String type = Users.ToString();

            foreach (String current in Users.ToList())
            {
                if (current == "CommonUser")
                {
                    isSuperUser = false;
                }
                else
                {
                    isSuperUser = true;
                }
            }

            if (isSuperUser == true)
            {
                InfoModule.ManageUserWindow manageUserWindow = new InfoModule.ManageUserWindow();
                //manageUserWindow.Show();
                manageUserWindow.ShowDialog();
              //this.Close();
            }

            if (isSuperUser == false)
            {
                MessageBox.Show("您没有权限！");
            }
        }


    }
}