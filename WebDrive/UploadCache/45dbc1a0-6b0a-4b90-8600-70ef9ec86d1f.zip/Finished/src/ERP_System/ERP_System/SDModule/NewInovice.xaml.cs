﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System.SDModule
{
    /// <summary>
    /// NewInovice.xaml 的互動邏輯
    /// </summary>
    public partial class NewInovice : Window
    {
        private int getInvoiceID;
        private ERP_DBEntities db = new ERP_DBEntities();

        public NewInovice(int InvoiceID)
        {
            InitializeComponent();
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
            InvoiceIDTextBox.Text = InvoiceID.ToString();
            getInvoiceID = InvoiceID;
            //init invoice
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            //reload datagrid
            ERP_System.ERP_DBDataSet eRP_DBDataSet = ((ERP_System.ERP_DBDataSet)(this.FindResource("eRP_DBDataSet")));
            // 将数据加载到表 deliveryOrder 中。
            ERP_System.ERP_DBDataSetTableAdapters.deliveryOrderTableAdapter eRP_DBDataSetdeliveryOrderTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.deliveryOrderTableAdapter();
            eRP_DBDataSetdeliveryOrderTableAdapter.Fill(eRP_DBDataSet.deliveryOrder);
            System.Windows.Data.CollectionViewSource deliveryOrderViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("deliveryOrderViewSource")));
            deliveryOrderViewSource.View.MoveCurrentToFirst();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var selectRow = (System.Data.DataRowView)deliveryOrderDataGrid.SelectedItem;
            int deliveryID = -1;
            //some input check!
            try
            {
                deliveryID = (int)selectRow["deliveryOrderID"];
            }
            catch
            {
                MessageBox.Show("请选择发货单！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            int year = -1;
            try
            {
                year = int.Parse(YearTextBox.Text);
            }
            catch
            {
                MessageBox.Show("请输入正确的年份！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (CurrencyTextBox.Text == null)
            {
                MessageBox.Show("请输入正确的货币！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            //select some useful info in order to write them to the db
            String currency = CurrencyTextBox.Text.ToString();
            var selectDeliveryOrder = from d in db.deliveryOrder where d.deliveryOrderID == deliveryID select d;
            deliveryOrder delivery = selectDeliveryOrder.First();
            int salesOrderID = delivery.salesOrder;
            var selectSalesOrder = from b in db.salesOrder where b.salesOrderID == salesOrderID select b;
            salesOrder sales = selectSalesOrder.First();
            invoice addInvoice = new invoice()
            {
                companyCode = delivery.companyCode,
                invoiceID = deliveryID,
                fiscalYear = year,
                currency = currency,
                amount = sales.amount,
                creationDate = System.DateTime.Now
            };
            try
            {
                db.invoice.Add(addInvoice);
                db.SaveChanges();
                //write to db
            }
            catch
            {
                db.invoice.Remove(addInvoice);
                MessageBox.Show("数据库读写错误！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            this.Close();
        }
    }
}
