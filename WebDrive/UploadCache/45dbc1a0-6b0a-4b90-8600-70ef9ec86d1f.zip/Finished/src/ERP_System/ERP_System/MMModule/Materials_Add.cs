﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.MMModule
{
    class Materials_Add
    {
        private Db_Operate DataBase_Operate; //db related var.
        private materials NewMaterials;
        public Materials_Add()
        {
            DataBase_Operate = new Db_Operate();
        }
        public void Set(int MaterialId,string Name,int VendorCode,int Stock,string PlaceOfOrigin)
        {
            //set materials info
            DataBase_Operate = new Db_Operate();
            NewMaterials = new materials()
            {
                materialID = MaterialId,
                name = Name,
                vendorCode = VendorCode,
                stock = Stock,
                placeOfOrigin = PlaceOfOrigin,
                //quantity = Convert.ToInt16(MaterialsQuantityBox)
            };
        }

        public void Add()
        {
            DataBase_Operate.Materials_AddNew(NewMaterials);
            //add a new materials.
        }

        public List<string> GetVendorCode()
        {
            return DataBase_Operate.Vendor_GetVendorCode();
        }

    }
}
