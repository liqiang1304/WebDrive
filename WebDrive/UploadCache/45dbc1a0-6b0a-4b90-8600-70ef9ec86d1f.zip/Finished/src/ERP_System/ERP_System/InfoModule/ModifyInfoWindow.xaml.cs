﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System.InfoModule
{
    /// <summary>
    /// ModifyInfoWindow.xaml 的互動邏輯
    /// </summary>
    public partial class ModifyInfoWindow : Window
    {

        private ERP_DBEntities db;
        String Username;
        String Password;
        int UserId;

        public ModifyInfoWindow(String username, String password)
        {   
            Username = username;
            Password = password;

            InitializeComponent();
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
            // connect to database
            db = new ERP_DBEntities();
            // find target user
            var targetUsers = from d in db.user where d.Username == Username select d;

            user targetUser = null;
            foreach (user entry in targetUsers.ToList())
            {
                //if (entry.Password == Password)
                //{
                //    targetUser = entry;
                //    break;
                //}
                targetUser = entry;
            }

            UserId = targetUser.Id;

            // get default information
            String UsernameStr = targetUser.Username;
            String PasswordStr = targetUser.Password;
            String GenderStr = targetUser.Gender;
            String NameStr = targetUser.Name;
            String EmailStr = targetUser.Email;
            String TelStr = targetUser.Tel;

            // initialize default information
            userName.Text = UsernameStr;

            if (GenderStr == "Male") male.IsChecked = true;
            if (GenderStr == "Female") female.IsChecked = true;
            if (GenderStr == "Unknown") unknown.IsChecked = true;

            name.Text = NameStr;
            email.Text = EmailStr;
            tel.Text = TelStr;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            // get all user information
            String UsernameStr = userName.Text.ToString();
            String PasswordStr = password.Password.ToString();
            String ConfirmStr = confirmPassword.Password.ToString();

            Boolean Male = false;
            if (male.IsChecked == true) Male = true;

            Boolean Female = false;
            if (female.IsChecked == true) Female = true;

            Boolean Unknown = false;
            if (unknown.IsChecked == true) Unknown = true;

            String NameStr = name.Text.ToString();
            String EmailStr = email.Text.ToString();
            String TelStr = tel.Text.ToString();

            // check all the errors in the process of creating a new user
            Boolean noError = true;
            while (true)
            {
                // forget to enter username and password
                if (UsernameStr != Username)
                {
                    MessageBox.Show("您不能更改用户名");
                    noError = false;
                    break;
                }

                // forget to enter password
                if (PasswordStr == "")
                {
                    MessageBox.Show("请输入密码");
                    noError = false;
                    break;
                }

                // forget to confirm password
                if (ConfirmStr == "")
                {
                    MessageBox.Show("请确认密码");
                }

                // forget to choose gender
                if ((Male == false) && (Female == false) && (Unknown == false))
                {
                    MessageBox.Show("请选择用户姓名");
                    noError = false;
                    break;
                }

                // forget to enter real name
                if (NameStr == "")
                {
                    MessageBox.Show("请输入用户真实姓名");
                    noError = false;
                    break;
                }

                // forget tot enter email address
                if (EmailStr == "")
                {
                    MessageBox.Show("请输入邮件地址");
                    noError = false;
                    break;
                }

                // confirm password and password are inconsistent
                if (PasswordStr != ConfirmStr)
                {
                    MessageBox.Show("两次输入密码不一致，请检查");
                    noError = false;
                    break;
                }

                if (noError == true) break;
            }

            if (noError == true)
            {
                // get all information of user
                String GenderStr = null;

                // choose gender of the user
                if (male.IsChecked == true) GenderStr = "Male";
                if (female.IsChecked == true) GenderStr = "Female";
                if (unknown.IsChecked == true) GenderStr = "Unknown";

                // all errors in input have been checked, start to change the information of target user
                // connection string
                db = new ERP_DBEntities();

                // get target user 
                var targetUsers = from d in db.user where d.Id == UserId select d;
                user targetUser = null;
                foreach (user entry in targetUsers.ToList())
                {
                    if (entry.Id == UserId)
                    {
                        targetUser = entry;
                        break;
                    }
                }

                // set new information for the user
                targetUser.Username = UsernameStr;
                targetUser.Password = PasswordStr;
                targetUser.Gender = GenderStr;
                targetUser.Name = NameStr;
                targetUser.Email = EmailStr;
                targetUser.Tel = TelStr;

                // change information for the user
                db.SaveChanges();

                // close this window
                this.Close();
            }
            else if (noError == false)
            {
                this.Close();
            }
        
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
