﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System
{
    class Db_Operate
    {
        private ERP_DBEntities db;

        public Db_Operate()
        {
            db = new ERP_DBEntities();

        }

        public bool Vendor_Add(vendor vendor)
        {
            try
            {
                db.vendor.Add(vendor);
                db.SaveChanges();
            }
            catch(DbEntityValidationException dbEx)
            {
                return false;
            }
            return true;
        }

        public List<string> Vendor_GetVendorCode()
        {
            List<string> vendorcode = new List<string>();
            var VendorCode = from v in db.vendor select v.vendorCode;
            //return Convert.ToString(VendorCode.ToList());
            foreach (var Code in VendorCode)
            {
                vendorcode.Add(Convert.ToString(Code));
            }
            return vendorcode;

        }
        

        public bool Materials_AddNew(materials material)
        {
            try
            {
                db.materials.Add(material);
                db.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                return false;
            }
            return true;
        }

        public List<string> Materials_GetMaterialsID()
        {
            List<string> materialsid = new List<string>();
            var MaterialsCode = from m in db.materials select m.materialID;
            foreach (var ID in MaterialsCode)
            {
                materialsid.Add(Convert.ToString(ID));
            }
            return materialsid;
        }
        public List<string> Materials_GetMaterialsName()
        {
            List<string> materialsname = new List<string>();
            var MaterialsName = from m in db.materials select m.name;
            foreach (var Name in MaterialsName)
            {
                materialsname.Add(Convert.ToString(Name));
            }
            return materialsname;
        }
        public List<string> Materials_GetSelectedVendorName(string name)
        {
            List<string> vendorcode = new List<string>();
            var VendorCode = from m in db.materials where m.name == name select m.vendorCode;
            foreach (var Vendor in VendorCode)
            {
                vendorcode.Add(Convert.ToString(Vendor));
            }
            return vendorcode;
        }
        public materials Materials_GetSelectedUnitPrice(string name, int vendorcode)
        {
            materials SelectedMaterials = db.materials.FirstOrDefault(materials => materials.name == name && materials.vendorCode == vendorcode);
            return SelectedMaterials;
                
        }
        public bool Materials_ChangeSelectedUnitPrice(string name, int vendorcode, decimal unitprice)
        {
            try
            {
                materials SelectedMaterials = db.materials.FirstOrDefault(materials => materials.name == name && materials.vendorCode == vendorcode);
                SelectedMaterials.unitPrice = unitprice;
                db.SaveChanges();
            }
            catch
            {
                return false;
            }
            return true;
        }
        public List<string> Materials_GetSelectedMaterialsInfo(int ID)
        {
            List<string> selectedInfo = new List<string>();
            var MaterialsName = from m in db.materials where m.materialID == ID select m.name;
            foreach (var Name in MaterialsName)
            {
                selectedInfo.Add(Convert.ToString(Name));
            }
            var MaterialsVendorCode = from m in db.materials where m.materialID == ID select m.vendorCode;
            foreach (var Code in MaterialsVendorCode)
            {
                selectedInfo.Add(Convert.ToString(Code));
            }
            var MaterialsStock = from m in db.materials where m.materialID == ID select m.stock;
            foreach (var Stock in MaterialsStock)
            {
                selectedInfo.Add(Convert.ToString(Stock));
            }
            var MaterialsOrigin = from m in db.materials where m.materialID == ID select m.placeOfOrigin;
            foreach (var Origin in MaterialsOrigin)
            {

                selectedInfo.Add(Convert.ToString(Origin));
            }
            var MaterialsQuantity = from m in db.materials where m.materialID == ID select m.quantity;
            foreach (var Quantity in MaterialsQuantity)
            {
                selectedInfo.Add(Convert.ToString(Quantity));
            }

            return selectedInfo;

        }

        public bool Materials_ExtendInfo(materials Selectedmaterials)
        {
            try
            {

                materials ChangeMaterials = db.materials.FirstOrDefault(materials => materials.materialID == Selectedmaterials.materialID);
                ChangeMaterials.describtion = Selectedmaterials.describtion;
                ChangeMaterials.unitPrice = Selectedmaterials.unitPrice;
                ChangeMaterials.discount = Selectedmaterials.discount;
                db.SaveChanges();
            }
            //catch (DbEntityValidationException dbEx)
            catch
            {
                return false;
            }
            materials update = db.materials.FirstOrDefault(materials => materials.materialID == Selectedmaterials.materialID);
            Console.WriteLine(update.describtion);
            return true;
        }
        public bool Materials_SetRequisitionQuantity(materials Changedmaterials)
        {
            try
            {
                materials ChangeMaterials = db.materials.FirstOrDefault(materials => materials.materialID == Changedmaterials.materialID);
                ChangeMaterials.quantity = Changedmaterials.quantity;
                db.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                return false;
            }
            return true;
        }

        public bool Requisition_NewRequisition(requisition newrequisition,re_ven_ma newre_ven_ma)
        {
            try
            {
                db.requisition.Add(newrequisition);
                db.re_ven_ma.Add(newre_ven_ma);
                db.SaveChanges();
            }
            catch
            {
                return false;
            }
            return true;
        }

        public re_ven_ma Re_ven_ma_GetRequisitionInfo(int id)
        {
            re_ven_ma SelectedRequisition = db.re_ven_ma.FirstOrDefault(re_ven_ma => re_ven_ma.requisitionID == id);
            return SelectedRequisition;
        }
        public bool RFQ_NewRFQ(rfq newrfq, rfq_ven_ma newrfq_ven_ma)
        {
            try
            {
                db.rfq.Add(newrfq);
                db.rfq_ven_ma.Add(newrfq_ven_ma);
                db.SaveChanges();
            }
            catch
            {
                return false;
            }
            return true;
        }

        public List<string> RFQ_GetRFQID()
        {
            List<string> RFQid = new List<string>();
            var RFQID = from r in db.rfq select r.rfqID;
            foreach (var ID in RFQID)
            {
                RFQid.Add(Convert.ToString(ID));
            }
            return RFQid;
        }

        public rfq_ven_ma RFQ_ven_ma_GetRFQInfo(int id)
        {
            rfq_ven_ma SelectedRFQ = db.rfq_ven_ma.FirstOrDefault(rfq_ven_ma => rfq_ven_ma.rfqID == id);
            return SelectedRFQ;
        }

        public bool OrderForm_NewOrderForm(orderForm neworderform, orderForm_ma neworderform_ma)
        {
            try
            {
                db.orderForm.Add(neworderform);
                db.orderForm_ma.Add(neworderform_ma);
                db.SaveChanges();
            }
            catch
            {
                return false;
            }
            return true;
        }

        public List<string> OrderForm_GetSelectedOrderFormInfo(int orderformid)
        {
            List<string> Selected = new List<string>();
            orderForm SelectedOrderForm = db.orderForm.FirstOrDefault(orderForm => orderForm.orderFormID == orderformid);
            orderForm_ma SelectedOrderForm_Ma = db.orderForm_ma.FirstOrDefault(orderForm_ma => orderForm_ma.orderFormID == orderformid);
            int SelectedMaterialsID = SelectedOrderForm_Ma.materialID;
            materials SelectedMaterials = db.materials.FirstOrDefault(materials => materials.materialID == SelectedMaterialsID);
            Selected.Add(Convert.ToString(SelectedOrderForm_Ma.materialID));
            Selected.Add(Convert.ToString(SelectedOrderForm.vendorCode));
            Selected.Add(Convert.ToString(SelectedMaterials.quantity));
            Selected.Add(Convert.ToString((int)SelectedMaterials.unitPrice));
            return Selected;
        }

        public bool Receipt_NewReceipt(receipt newreceipt)
        {
            try
            {
                db.receipt.Add(newreceipt);
                db.SaveChanges();
            }
            catch
            {
                return false;
            }
            return true;
        }

        public List<string> OrderForm_GetOrderFormID()
        {
            List<string> OrderFormID = new List<string>();
            var orderformid = from o in db.orderForm select o.orderFormID;

            foreach (var ID in orderformid)
            {
                OrderFormID.Add(Convert.ToString(ID));
            }
            return OrderFormID;
        }


        public bool Materials_AddSelectedMaterialsStock(materials changedmaterials)
        {
            try
            {
                materials ChangeMaterials = db.materials.FirstOrDefault(materials => materials.materialID == changedmaterials.materialID);
                ChangeMaterials.stock += changedmaterials.quantity;
                ChangeMaterials.quantity = 0;
                db.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                return false;
            }
            return true;
        }


        public List<string> Requisition_GetRequisitionID()
        {
            List<string> requisitionid = new List<string>();
            var RequisitionID = from r in db.requisition select r.requisitionID;
            foreach (var ID in RequisitionID)
            {
                requisitionid.Add(Convert.ToString(ID));
            }
            return requisitionid;
        }

    }

    
}
