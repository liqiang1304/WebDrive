﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.MMModule
{
    class RFQ_Add
    {
        private Db_Operate DataBase_Operate; //db related var.
        private rfq NewRFQ;
        private rfq_ven_ma RFQ_Ven_Ma;
        public RFQ_Add()
        {
            DataBase_Operate = new Db_Operate();
        }
        public void Set(int RFQID,DateTime CurrentTime,int VendorCode,int MaterialID)
        {
            //set infomation to db.
            System.DateTime quotation = new DateTime(2014, 01, 01);
            NewRFQ = new rfq
            {
                rfqID = RFQID,
                quotationDate = quotation,
                creationDate = CurrentTime
            };
            RFQ_Ven_Ma = new rfq_ven_ma
            {
                rfqID = RFQID,
                vendorCode = VendorCode,
                materialID = MaterialID
            };
            
        }
        public void Add()
        {
            //add it to db
            DataBase_Operate.RFQ_NewRFQ(NewRFQ, RFQ_Ven_Ma);
        }

        public re_ven_ma GetRequisitionInfo(int selected)
        {
            return DataBase_Operate.Re_ven_ma_GetRequisitionInfo(selected);
        }

        public List<string> GetRequisitionID()
        {
            return DataBase_Operate.Requisition_GetRequisitionID();
        }
    }
}
