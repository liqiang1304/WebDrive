﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.MMModule
{
    class Materials_Extend
    {
        private Db_Operate DataBase_Operate; //db related var.
        private materials NewMaterials;
        public Materials_Extend()
        {
            DataBase_Operate = new Db_Operate();
        }
        public void Set(int ID,decimal UnitPrice,decimal Discount,string Description)
        {
            //add extend info to materials
            NewMaterials = new materials()
            {
                materialID = ID,
                unitPrice = UnitPrice,
                discount = Discount,
                describtion = Description
            };

            DataBase_Operate = new Db_Operate();

            
        }
        public bool Extend()
        {
             return DataBase_Operate.Materials_ExtendInfo(NewMaterials);
            //add info to db.
        }

        public List<string> GetMaterialsID()
        {
            return DataBase_Operate.Materials_GetMaterialsID();
        }

        public List<string> GetSelectedMaterialsInfo(int selected)
        {
            return DataBase_Operate.Materials_GetSelectedMaterialsInfo(selected);
        }
    }
}
