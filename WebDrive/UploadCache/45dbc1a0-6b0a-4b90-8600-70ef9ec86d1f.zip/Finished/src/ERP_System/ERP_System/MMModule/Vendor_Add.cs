﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.MMModule
{
    class Vendor_Add
    {
        private Db_Operate DataBase_Operate; //db related var.
        private vendor NewVendor;
        public Vendor_Add()
        {
            DataBase_Operate = new Db_Operate();
        }
        public void Set(int VendorCode,string Name,string Location,string Currency,decimal TaxRate)
        {
            //add to db to set it to the vendor
            DataBase_Operate = new Db_Operate();
            NewVendor = new vendor()
            {
                vendorCode = VendorCode,
                name = Name,
                location = Location,
                currency = Currency,
                taxRate = TaxRate
            };


        }

        public void Add()
        {
            //add it to db.
            DataBase_Operate.Vendor_Add(NewVendor);
            
        }
    }
}
