﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.MMModule
{
    class Requisition_Add
    {
        private Db_Operate DataBase_Operate; //db related var.
        private requisition NewRequisition;
        private re_ven_ma Re_Ven_Ma;
        private materials NewMaterials;
        public Requisition_Add()
        {
            DataBase_Operate = new Db_Operate();
        }
        public void Set(int RequisitionID,DateTime CurrentTime,int MaterialID,int VendorCode,int Quantity)
        {
            //set get info to a class in order to save to db.
            NewRequisition = new requisition
            {
                requisitionID = RequisitionID,
                bidDate = CurrentTime
            };
            //requistition table
            Re_Ven_Ma = new re_ven_ma
            {
                requisitionID = RequisitionID,
                materialID = MaterialID,
                vendorCode = VendorCode
            };
            //Re_Ven_Ma table
            NewMaterials = new materials()
            {
                materialID = MaterialID,
                quantity = Quantity
            };
            //Materials table;

        }
        public void Add()
        {
            //add it to db.
            DataBase_Operate.Requisition_NewRequisition(NewRequisition, Re_Ven_Ma);
            DataBase_Operate.Materials_SetRequisitionQuantity(NewMaterials);
        }
        public List<string> GetVendorCode()
        {
            return DataBase_Operate.Vendor_GetVendorCode();
        }
        public List<string> GetMaterialsID()
        {
            return DataBase_Operate.Materials_GetMaterialsID();
        }
        public List<string> GetSelectedMaterialsInfo(int selected)
        {
            return DataBase_Operate.Materials_GetSelectedMaterialsInfo(selected);
        }
    }
}
