﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System.MMModule
{
    /// <summary>
    /// MMWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MMWindow : Window
    {
        private Vendor_Add vendor_Add;
        private Materials_Add materials_Add;
        private Materials_Extend materials_Extend;
        private Requisition_Add requisition_Add;
        private RFQ_Add rfq_Add;
        private Materials_Maintain materials_Maintain;
        private OrderForm_Add orderform_Add;
        private OrderForm_Check orderform_Check;
        private Receipt_Add receipt_Add;
        private Material_Check materials_Check;

        private InputCheck input_check;
        private System.DateTime currentTime;
        public MMWindow()
        {
            InitializeComponent();

            vendor_Add = new Vendor_Add();
            materials_Add = new Materials_Add();
            materials_Extend = new Materials_Extend();
            requisition_Add = new Requisition_Add();
            rfq_Add = new RFQ_Add();
            materials_Maintain = new Materials_Maintain();
            orderform_Add = new OrderForm_Add();
            orderform_Check = new OrderForm_Check();
            receipt_Add = new Receipt_Add();
            materials_Check = new Material_Check();


            input_check = new InputCheck();
            currentTime = new System.DateTime();
            currentTime = System.DateTime.Now;
            //tab1
            CurrencyComboBox.Items.Add("U");
            CurrencyComboBox.Items.Add("R");
            TaxRateSlider.Maximum = 1;
            TaxRateSlider.Minimum = 0;


            
            //tab2

            VendorCodeCombox.ItemsSource = materials_Add.GetVendorCode();
            

            //tab3
            MaterialsIDCombox.ItemsSource = materials_Extend.GetMaterialsID();

            //tab4
            String requisitionDate = currentTime.ToString("d");
            RequisitionDate.Text = requisitionDate;
            //requisitionDate = requisitionDate.Remove(4, 1);
            //requisitionDate = requisitionDate.Remove(6, 1);
            //RequisitionID.Text = requisitionDate.Insert(requisitionDate.Length, );
            RequisitionID.Text = Convert.ToString(currentTime.Millisecond);
            VendorCodeComboBoxTab4.ItemsSource = requisition_Add.GetVendorCode();
            MaterialsCodeComboboxTab4.ItemsSource = requisition_Add.GetMaterialsID();


            //tab5
            String RFQDate = currentTime.ToString("d");
            RFQCreationDateBox.Text = RFQDate;
            RFQIDBox.Text = Convert.ToString(currentTime.Millisecond);
            RFQQuotationDateBox.Text = "2014-01-01";
            RFQRequisitionIDComboxBox.ItemsSource = rfq_Add.GetRequisitionID();

            //tab5.2
            MaintainMaterialsNameComboBox.ItemsSource = materials_Maintain.GetMaterialsName();

            //5.6
            //MaterialsUnitPriceDataGrid.


            //tab6

            OrderFormRFQIDComboBox.ItemsSource = orderform_Add.GetRFQID();

            //tab7
            OrderFormOrderIDComboBox.ItemsSource = orderform_Check.GetOrderFormID();
            //tab8
            OrderFormOrderIDComboBox_Copy.ItemsSource = receipt_Add.GetOrderFormID();

            //tab9
            MaterialsIDCombox_Copy.ItemsSource = materials_Check.GetMaterialsID();
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
        }



        //tab1
        private void Save_NewVendor(object sender, RoutedEventArgs e)
        {
            
            String vender_code = CodeBox.Text;
            if (input_check.IsOnlyNumber(vender_code) && NameBox!=null)
            {
                String vender_name = NameBox.Text;
                String vender_location = LocationBox.Text;
                String vender_currency = Convert.ToString(CurrencyComboBox.SelectedItem);
                if (vender_currency == null)
                {
                    MessageBox.Show("请选择供应商币种", "输入错误！");
                }
                else
                {
                    decimal vender_taxrate;
                    int taxrate = Convert.ToInt32(TaxRateSlider.Value * 100);
                    vender_taxrate = taxrate / 100;
                    try
                    {
                        try
                        {
                            int iVendorCode = int.Parse(vender_code);
                        }
                        catch
                        {
                            MessageBox.Show("输入有误！", "错误！");
                            return;
                        }
                        vendor_Add.Set(int.Parse(vender_code), vender_name, vender_location, vender_currency, vender_taxrate);
                        vendor_Add.Add();
                        
                    }
                    catch (DbEntityValidationException dbEx)
                    {
                        
                    }

                    VendorCodeCombox.ItemsSource = materials_Add.GetVendorCode();
                    MessageBox.Show("成功创建新供应商");
                }

            }
            else
            {
                MessageBox.Show("供应商代码输入错误，应为纯数字", "输入错误！");
            }
        }
        private void Clear_NewVendor(object sender, RoutedEventArgs e)
        {
            CodeBox.Text = "";
            NameBox.Text = "";
            LocationBox.Text = "";
            TaxRateSlider.Value = 0;
            CurrencyComboBox.SelectedIndex = -1;
        }
        private void TaxRateSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            int taxrate = Convert.ToInt32(TaxRateSlider.Value * 100);
            string vender_taxrate = Convert.ToString(taxrate);
            vender_taxrate = vender_taxrate.Insert(vender_taxrate.Length, "%");
            TaxRateLabel.Content = vender_taxrate;
        }



        //tab2
        private void Save_NewMaterials(object sender, RoutedEventArgs e)
        {
            try
            {
                int iMaterialsID = -1;
                int iVendorCode = -1;
                int iMaterialsStock = -1;
                try
                {
                    iMaterialsID = int.Parse(MaterialsIDBox.Text);
                    iVendorCode = int.Parse(VendorCodeCombox.Text);
                    iMaterialsStock = int.Parse(MaterialsStock.Text);
                }
                catch
                {
                    MessageBox.Show("输入有误！请检查！", "错误！");
                    return;
                }
                materials_Add.Set(iMaterialsID, MaterialsNameBox.Text, iVendorCode, iMaterialsStock, MaterialsOriginBox.Text);
                materials_Add.Add();
                MessageBox.Show("成功创建新物料");
                
            }
            catch (DbEntityValidationException dbEx)
            {

            }
            MaterialsIDCombox.ItemsSource = materials_Extend.GetMaterialsID();
            
        }

        private void Clear_NewMaterials(object sender, RoutedEventArgs e)
        {
            MaterialsIDBox.Text = "";
            MaterialsNameBox.Text = "";
            MaterialsOriginBox.Text = "";
            MaterialsStock.Text = "";
            VendorCodeCombox.SelectedIndex = -1;
        }



        //tab3
        private void Clear_ExtendMaterials(object sender, RoutedEventArgs e)
        {

        }

        private void Save_ExtendMaterials(object sender, RoutedEventArgs e)
        {
            try
            {
                materials_Extend.Set(Convert.ToInt32(MaterialsIDCombox.SelectedItem),
                    Convert.ToDecimal(MaterialsUnitPriceBox.Text),
                    Convert.ToDecimal(MaterialsDiscountBox.Text),
                    MaterialsDescribtionBox.Text);

            }
            catch
            {
                MessageBox.Show("输入有误！无法存入数据库！", "错误！");
                return;
            }

            if (materials_Extend.Extend())
            {
                MessageBox.Show("成功扩展物料");
                VendorCodeComboBoxTab4.ItemsSource = requisition_Add.GetVendorCode();
                MaterialsCodeComboboxTab4.ItemsSource = requisition_Add.GetMaterialsID();
            }
            else
            {
                MessageBox.Show("输入有误！无法存入数据库！", "错误！");
                return;
            }
        }

        private void GetSelectedMaterialsInfo(object sender, SelectionChangedEventArgs e)
        {
            List<string> SelectedMaterialsInfo = new List<string>();
            int selected = Convert.ToInt16(MaterialsIDCombox.SelectedItem);

            SelectedMaterialsInfo = materials_Extend.GetSelectedMaterialsInfo(selected);
            MaterialsNameBoxShow.Text = SelectedMaterialsInfo.ElementAt(0);
            VendorCodeBoxShow.Text = SelectedMaterialsInfo.ElementAt(1);
            MaterialsStockShow.Text = SelectedMaterialsInfo.ElementAt(2);
            MaterialsOriginBoxShow.Text = SelectedMaterialsInfo.ElementAt(3);
            //MaterialsQuantityBoxShow.Text = SelectedMaterialsInfo.ElementAt(4);


        }



        //tab4

        private void FindSelectedMaterialsVendor(object sender, SelectionChangedEventArgs e)
        {
            VendorCodeComboBoxTab4.IsEnabled = true;
            //VendorCodeComboBoxTab4.ItemsSource = materials_Maintain.GetSelectedVendorName(Convert.ToString(MaterialsCodeComboboxTab4.SelectedItem));
            List<string> SelectedMaterialsInfo = new List<string>();
            int selected = Convert.ToInt16(MaterialsCodeComboboxTab4.SelectedItem);

            SelectedMaterialsInfo = requisition_Add.GetSelectedMaterialsInfo(selected);
            MaterialsNameBoxShowTab4.Text = SelectedMaterialsInfo.ElementAt(0);
        }

        private void Save_NewRequisition(object sender, RoutedEventArgs e)
        {
            try
            {

                requisition_Add.Set(Convert.ToInt16(RequisitionID.Text), currentTime, Convert.ToInt16(MaterialsCodeComboboxTab4.SelectedItem), Convert.ToInt16(VendorCodeComboBoxTab4.SelectedItem), Convert.ToInt16(RequisitionQuantityBox.Text));
                requisition_Add.Add();
                MessageBox.Show("成功创建新请购单");
            }
            catch
            {
                MessageBox.Show("您的输入有误！", "错误！");
                return;
            }
            RFQRequisitionIDComboxBox.ItemsSource = rfq_Add.GetRequisitionID();
        }


        //tab5
        private void FindSelectedRequisitionIDInfo(object sender, SelectionChangedEventArgs e)
        {
            int selected = Convert.ToInt16(RFQRequisitionIDComboxBox.SelectedItem);
            re_ven_ma SelectedRequisition = rfq_Add.GetRequisitionInfo(selected);
            RFQVendorCodeBox.Text = Convert.ToString(SelectedRequisition.vendorCode);
            RFQMaterialsIDBox.Text = Convert.ToString(SelectedRequisition.materialID);
        }

        private void Save_NewRFQ(object sender, RoutedEventArgs e)
        {
            try
            {
                rfq_Add.Set(Convert.ToInt16(RFQIDBox.Text), currentTime, Convert.ToInt16(RFQVendorCodeBox.Text), Convert.ToInt16(RFQMaterialsIDBox.Text));
                rfq_Add.Add();
                MessageBox.Show("成功创建RFQ");
                MaintainMaterialsNameComboBox.ItemsSource = materials_Maintain.GetMaterialsName();
            }
            catch
            {
                MessageBox.Show("数据库读写错误！请选择！", "错误！");
            }
        }

        //tab5.2
        private void FindSelectedMaterialsNameInfo(object sender, SelectionChangedEventArgs e)
        {
            MaintainMaterialsVendorCodeComboBox.ItemsSource = materials_Maintain.GetSelectedVendorName(Convert.ToString(MaintainMaterialsNameComboBox.SelectedItem));
        }
        private void FindSelectedMaterialsUnitPrice(object sender, SelectionChangedEventArgs e)
        {
            materials Selected = new materials();
            Selected = materials_Maintain.GetSelectedUnitPrice(Convert.ToString(MaintainMaterialsNameComboBox.SelectedItem), Convert.ToInt16(MaintainMaterialsVendorCodeComboBox.SelectedItem));
            MaintainMaterialsUnitPriceBox.Text = Convert.ToString(Selected.unitPrice);
        }
        private void Save_ChangedMaterialsUnitPrice(object sender, RoutedEventArgs e)
        {
            materials Selected = new materials();
            Selected = materials_Maintain.GetSelectedUnitPrice(Convert.ToString(MaintainMaterialsNameComboBox.SelectedItem), Convert.ToInt16(MaintainMaterialsVendorCodeComboBox.SelectedItem));
            //Selected.unitPrice = Convert.ToInt16(MaintainMaterialsUnitPriceBox.Text);
            try
            {
                Selected.unitPrice = decimal.Parse(MaintainMaterialsUnitPriceBox.Text);
            }
            catch
            {
                MessageBox.Show("输入错误！","错误！");
                return;
            }
            //materials_Maintain.ChangeSelectedUnitPrice(Convert.ToString(MaintainMaterialsNameComboBox.SelectedItem), Convert.ToInt16(MaintainMaterialsVendorCodeComboBox.SelectedItem), Convert.ToInt16(MaintainMaterialsUnitPriceBox.Text));
            materials_Maintain.ChangeSelectedUnitPrice(Convert.ToString(MaintainMaterialsNameComboBox.SelectedItem), Convert.ToInt16(MaintainMaterialsVendorCodeComboBox.SelectedItem), decimal.Parse(MaintainMaterialsUnitPriceBox.Text));
            MessageBox.Show("成功维护报价");
            OrderFormRFQIDComboBox.ItemsSource = orderform_Add.GetRFQID();
        }





        //tab6
        private void FindSelectedRFQInfo(object sender, SelectionChangedEventArgs e)
        {
            int selected = Convert.ToInt16(OrderFormRFQIDComboBox.SelectedItem);
            rfq_ven_ma SelectedRFQ = orderform_Add.GetRFQInfo(selected);

            string OrderFormID = Convert.ToString(SelectedRFQ.rfqID + (int)(currentTime.Millisecond* 0.7));
            //OrderFormID = OrderFormID.Insert(OrderFormID.Length ,Convert.ToString(currentTime.Millisecond));
            OrderFormIDShowBox.Text = OrderFormID;

            OrderFormMaterialIDShowBox.Text = Convert.ToString(SelectedRFQ.materialID);
            OrderFormVendorIdShowBox.Text = Convert.ToString(SelectedRFQ.vendorCode);

        }

        private void Save_NewOrderForm(object sender, RoutedEventArgs e)
        {
            orderform_Add.Set(
                Convert.ToInt16(OrderFormVendorIdShowBox.Text),
                Convert.ToInt16(OrderFormIDShowBox.Text),
                Convert.ToInt16(OrderFormRFQIDComboBox.SelectedItem),
                Convert.ToInt16(OrderFormMaterialIDShowBox.Text)
            );
            orderform_Add.Add();
            MessageBox.Show("成功创建新订单");
            OrderFormOrderIDComboBox.ItemsSource = orderform_Check.GetOrderFormID();
            OrderFormOrderIDComboBox_Copy.ItemsSource = receipt_Add.GetOrderFormID();
        }

        //tab7
        private void FindSelectedOrderFormInfo(object sender, SelectionChangedEventArgs e)
        {
            List<string> Selected = new List<string>();
            Selected = orderform_Check.GetSelectedOrderFormInfo(Convert.ToInt16(OrderFormOrderIDComboBox.SelectedItem));
            OrderFormMaterialIDShowBoxShow.Text = Selected.ElementAt(0);
            OrderFormVendorIdShowBoxShow.Text = Selected.ElementAt(1);
            OrderFormQuantityShowBoxShow.Text = Selected.ElementAt(2);
        }



        //tab8
        private void FindSelectedOrderFormInfoReceipt(object sender, SelectionChangedEventArgs e)
        {
            List<string> Selected = new List<string>();
            Selected = receipt_Add.GetSelectedFormInfo(Convert.ToInt16(OrderFormOrderIDComboBox_Copy.SelectedItem));
            OrderFormMaterialIDShowBoxShow_Copy.Text = Selected.ElementAt(0);
            OrderFormVendorIdShowBoxShow_Copy.Text = Selected.ElementAt(1);
            OrderFormQuantityShowBoxShow_Copy.Text = Selected.ElementAt(2);
            ReceiptUnitPriceBox.Text = Selected.ElementAt(3);

        }

        

        private void Save_NewReceipt(object sender, RoutedEventArgs e)
        {
            int quantity = Convert.ToInt16(ReceiptQuantity.Text);
            int unitprice = Convert.ToInt32(ReceiptUnitPriceBox.Text);
            ReceiptAmount.Text = Convert.ToString(quantity * unitprice);
            receipt_Add.Set(Convert.ToInt16(OrderFormVendorIdShowBoxShow_Copy.Text),
                        Convert.ToInt16(OrderFormOrderIDComboBox_Copy.SelectedItem),
                        currentTime,
                        Convert.ToInt16(ReceiptAmount.Text),
                        Convert.ToInt16(ReceiptQuantity.Text),
                        Convert.ToInt16(OrderFormMaterialIDShowBoxShow_Copy.Text));
            receipt_Add.Add();

            MessageBox.Show("成功创建新收据");
            MaterialsIDCombox_Copy.ItemsSource = materials_Check.GetMaterialsID();

        }

        private void GetSelectedMaterialsChangedInfo(object sender, SelectionChangedEventArgs e)
        {
            List<string> SelectedMaterialsInfo = new List<string>();
            int selected = Convert.ToInt16(MaterialsIDCombox_Copy.SelectedItem);
            
            SelectedMaterialsInfo = materials_Check.GetSelectedMaterialsInfo(selected);
            MaterialsNameBoxShow_Copy.Text = SelectedMaterialsInfo.ElementAt(0);
            //VendorCodeBoxShow.Text = SelectedMaterialsInfo.ElementAt(1);
            MaterialsStockShow_Copy.Text = SelectedMaterialsInfo.ElementAt(2);
            //MaterialsOriginBoxShow.Text = SelectedMaterialsInfo.ElementAt(3);
        }

    }
}
