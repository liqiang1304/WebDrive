﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.MMModule
{
    class OrderForm_Add
    {
        private Db_Operate DataBase_Operate; //db related var.
        private orderForm OrderForm;
        private orderForm_ma OrderForm_Ma;
        public OrderForm_Add()
        {
            DataBase_Operate = new Db_Operate();
        }
        public void Set(int VendorCode,int OrderFormID,int RFQID,int MaterialID)
        {
            //set info to orderform
            OrderForm = new orderForm
            {
                vendorCode = VendorCode,
                orderFormID = OrderFormID,
                rfqID = RFQID
            };
            OrderForm_Ma = new orderForm_ma
            {
                rfqID = RFQID,
                orderFormID = OrderFormID,
                materialID = MaterialID
            };
            
        }
        public void Add()
        {
            //add orderform to db.
            DataBase_Operate.OrderForm_NewOrderForm(OrderForm, OrderForm_Ma);
        }
        public List<string> GetRFQID()
        {
            //get RFQ's ID
            return DataBase_Operate.RFQ_GetRFQID();
        }
        public rfq_ven_ma GetRFQInfo(int selected)
        {
            return DataBase_Operate.RFQ_ven_ma_GetRFQInfo(selected);
        }

    }
}
