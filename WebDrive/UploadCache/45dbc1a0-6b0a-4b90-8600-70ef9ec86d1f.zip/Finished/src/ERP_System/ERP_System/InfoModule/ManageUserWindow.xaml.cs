﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System.InfoModule
{
    /// <summary>
    /// ManageUserWindow.xaml 的互動邏輯
    /// </summary>
    public partial class ManageUserWindow : Window
    {
        private ERP_DBEntities db;

        public ManageUserWindow()
        {
            InitializeComponent();
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
        }

        private void confirm_Click(object sender, RoutedEventArgs e)
        {
            // get all user information
            String UsernameStr = userName.Text.ToString();
            String PasswordStr = password.Password.ToString();
            String ConfirmStr = confirmPassword.Password.ToString();

            Boolean Male = false;
            if (male.IsChecked == true) Male = true;

            Boolean Female = false;
            if (female.IsChecked == true) Female = true;

            Boolean Unknown = false;
            if (unknown.IsChecked == true) Unknown = true;

            
            String NameStr = name.Text.ToString();
            String EmailStr = email.Text.ToString();
            String TelStr = tel.Text.ToString();

            Boolean Superuser = false;
            if (superUser.IsChecked == true) Superuser = true;

            Boolean Commonuser = false;
            if (commonUser.IsChecked == true) Commonuser = true;
             
            // check all the errors in the process of creating a new user
            Boolean noError = true;
            while (true)
            {
                // forget to enter his username and password
                if (UsernameStr == "")
                {
                    MessageBox.Show("请输入用户名");
                    noError = false;
                    break;
                }

                // avoid the same username
                db = new ERP_DBEntities();
                var targetUsernames = from d in db.user where d.Username == UsernameStr select d.Username;
                Boolean exist = true;
                foreach (String entry in targetUsernames.ToList())
                {
                    if (entry == UsernameStr)
                    {
                        exist = false;
                    }
                }
                if (exist == false)
                {
                    MessageBox.Show("该用户名已存在");
                    noError = false;
                    break;
                }

                // forget to enter password
                if (PasswordStr == "")
                {
                    MessageBox.Show("请输入密码");
                    noError = false;
                    break;
                }

                // forget to confirm password
                if (ConfirmStr == "")
                {
                    MessageBox.Show("请确认密码");
                    noError = false;
                    break;
                }

                // forget to choose gender
                if ((Male == false) && (Female == false) && (Unknown == false))
                {
                    MessageBox.Show("请选择用户性别");
                    noError = false;
                    break;
                }

                // forget to enter real name
                if (NameStr == "")
                {
                    MessageBox.Show("请输入用户真实姓名");
                    noError = false;
                    break;
                }

                // forget to enter email address
                if (EmailStr == "")
                {
                    MessageBox.Show("请输入用户邮件地址");
                    noError = false;
                    break;
                }

                // forget to choose user type
                if ((Superuser == false) && (Commonuser == false))
                {
                    MessageBox.Show("请选择用户种类");
                    noError = false;
                    break;
                }

                // confirm password and password are inconsistent
                if (PasswordStr != ConfirmStr)
                {
                    MessageBox.Show("两次输入密码不一致，请检查");
                    noError = false;
                    break;
                }

                if (noError == true) break;
            }

            if (noError == true)
            {
                // get all information of user
                String GenderStr = null;
                String UsertypeStr = null;

                // choose gender of the user
                if (male.IsChecked == true) GenderStr = "Male";
                if (female.IsChecked == true) GenderStr = "Female";
                if (unknown.IsChecked == true) GenderStr = "Unknown";

                // choose user type
                if (superUser.IsChecked == true) UsertypeStr = "SuperUser";
                if (commonUser.IsChecked == true) UsertypeStr = "CommonUser";

                // all errors in input have been checked, start to insert record in user table
                // connection string
                db = new ERP_DBEntities();

                // find the largest user ID
                var Users = from d in db.user select d.Id;
                int maxId = 0;
                foreach (int currentId in Users.ToList())
                {
                    if (currentId > maxId)
                    {
                        maxId = currentId;
                    }
                }

                // create a new user
                user newUser = new user();

                // set information for the new user
                int newId = maxId + 1;
                newUser.Id = newId;
                newUser.Username = UsernameStr;
                newUser.Password = PasswordStr;
                newUser.Name = NameStr;
                newUser.Gender = GenderStr;
                newUser.Email = EmailStr;
                newUser.Tel = TelStr;
                newUser.Type = UsertypeStr;

                // insert the new user into user table
                db.user.Add(newUser);
                db.SaveChanges();
            }

            this.Close();
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
