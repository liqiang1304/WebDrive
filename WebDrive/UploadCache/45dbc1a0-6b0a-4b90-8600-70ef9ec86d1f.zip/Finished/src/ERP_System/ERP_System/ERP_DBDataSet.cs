﻿namespace ERP_System {
    
    
    public partial class ERP_DBDataSet {
        partial class inquriy_maDataTable
        {
        }
    }
}
