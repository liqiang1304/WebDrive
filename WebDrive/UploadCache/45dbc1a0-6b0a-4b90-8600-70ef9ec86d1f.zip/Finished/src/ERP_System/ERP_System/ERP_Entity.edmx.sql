
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 12/02/2013 12:25:40
-- Generated from EDMX file: C:\Users\Richard\Documents\Visual Studio 2012\Projects\Test_Project\ERP_System\ERP_System\ERP_Entity.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [ERP_DB];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK__contactPe__compa__145C0A3F]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[contactPerson] DROP CONSTRAINT [FK__contactPe__compa__145C0A3F];
GO
IF OBJECT_ID(N'[dbo].[FK__deliveryO__compa__21B6055D]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[deliveryOrder] DROP CONSTRAINT [FK__deliveryO__compa__21B6055D];
GO
IF OBJECT_ID(N'[dbo].[FK__deliveryO__sales__22AA2996]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[deliveryOrder] DROP CONSTRAINT [FK__deliveryO__sales__22AA2996];
GO
IF OBJECT_ID(N'[dbo].[FK__invo_ma__company__4D94879B]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[invo_ma] DROP CONSTRAINT [FK__invo_ma__company__4D94879B];
GO
IF OBJECT_ID(N'[dbo].[FK__invo_ma__invoice__4E88ABD4]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[invo_ma] DROP CONSTRAINT [FK__invo_ma__invoice__4E88ABD4];
GO
IF OBJECT_ID(N'[dbo].[FK__invo_ma__materia__4F7CD00D]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[invo_ma] DROP CONSTRAINT [FK__invo_ma__materia__4F7CD00D];
GO
IF OBJECT_ID(N'[dbo].[FK__invoice__company__25869641]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[invoice] DROP CONSTRAINT [FK__invoice__company__25869641];
GO
IF OBJECT_ID(N'[dbo].[FK__materials__vendo__34C8D9D1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[materials] DROP CONSTRAINT [FK__materials__vendo__34C8D9D1];
GO
IF OBJECT_ID(N'[dbo].[FK__orderForm__mater__5DCAEF64]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[orderForm_ma] DROP CONSTRAINT [FK__orderForm__mater__5DCAEF64];
GO
IF OBJECT_ID(N'[dbo].[FK__orderForm__order__5CD6CB2B]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[orderForm_ma] DROP CONSTRAINT [FK__orderForm__order__5CD6CB2B];
GO
IF OBJECT_ID(N'[dbo].[FK__orderForm__rfqID__2F10007B]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[orderForm] DROP CONSTRAINT [FK__orderForm__rfqID__2F10007B];
GO
IF OBJECT_ID(N'[dbo].[FK__orderForm__rfqID__5BE2A6F2]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[orderForm_ma] DROP CONSTRAINT [FK__orderForm__rfqID__5BE2A6F2];
GO
IF OBJECT_ID(N'[dbo].[FK__orderForm__vendo__2E1BDC42]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[orderForm] DROP CONSTRAINT [FK__orderForm__vendo__2E1BDC42];
GO
IF OBJECT_ID(N'[dbo].[FK__out_ma__companyC__48CFD27E]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[out_ma] DROP CONSTRAINT [FK__out_ma__companyC__48CFD27E];
GO
IF OBJECT_ID(N'[dbo].[FK__out_ma__delivery__49C3F6B7]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[out_ma] DROP CONSTRAINT [FK__out_ma__delivery__49C3F6B7];
GO
IF OBJECT_ID(N'[dbo].[FK__out_ma__material__4AB81AF0]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[out_ma] DROP CONSTRAINT [FK__out_ma__material__4AB81AF0];
GO
IF OBJECT_ID(N'[dbo].[FK__out_ma__salesOrd__47DBAE45]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[out_ma] DROP CONSTRAINT [FK__out_ma__salesOrd__47DBAE45];
GO
IF OBJECT_ID(N'[dbo].[FK__re_ven_ma__mater__534D60F1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[re_ven_ma] DROP CONSTRAINT [FK__re_ven_ma__mater__534D60F1];
GO
IF OBJECT_ID(N'[dbo].[FK__re_ven_ma__requi__52593CB8]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[re_ven_ma] DROP CONSTRAINT [FK__re_ven_ma__requi__52593CB8];
GO
IF OBJECT_ID(N'[dbo].[FK__re_ven_ma__vendo__5441852A]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[re_ven_ma] DROP CONSTRAINT [FK__re_ven_ma__vendo__5441852A];
GO
IF OBJECT_ID(N'[dbo].[FK__rece_ma__materia__619B8048]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[rece_ma] DROP CONSTRAINT [FK__rece_ma__materia__619B8048];
GO
IF OBJECT_ID(N'[dbo].[FK__rece_ma__receipt__60A75C0F]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[rece_ma] DROP CONSTRAINT [FK__rece_ma__receipt__60A75C0F];
GO
IF OBJECT_ID(N'[dbo].[FK__receipt__vendorC__31EC6D26]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[receipt] DROP CONSTRAINT [FK__receipt__vendorC__31EC6D26];
GO
IF OBJECT_ID(N'[dbo].[FK__rfq_ven_m__mater__59063A47]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[rfq_ven_ma] DROP CONSTRAINT [FK__rfq_ven_m__mater__59063A47];
GO
IF OBJECT_ID(N'[dbo].[FK__rfq_ven_m__rfqID__571DF1D5]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[rfq_ven_ma] DROP CONSTRAINT [FK__rfq_ven_m__rfqID__571DF1D5];
GO
IF OBJECT_ID(N'[dbo].[FK__rfq_ven_m__vendo__5812160E]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[rfq_ven_ma] DROP CONSTRAINT [FK__rfq_ven_m__vendo__5812160E];
GO
IF OBJECT_ID(N'[dbo].[FK__sales_ma__compan__4222D4EF]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[sales_ma] DROP CONSTRAINT [FK__sales_ma__compan__4222D4EF];
GO
IF OBJECT_ID(N'[dbo].[FK__sales_ma__materi__44FF419A]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[sales_ma] DROP CONSTRAINT [FK__sales_ma__materi__44FF419A];
GO
IF OBJECT_ID(N'[dbo].[FK__sales_ma__salesO__440B1D61]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[sales_ma] DROP CONSTRAINT [FK__sales_ma__salesO__440B1D61];
GO
IF OBJECT_ID(N'[dbo].[FK__salesOrde__compa__1DE57479]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[salesOrder] DROP CONSTRAINT [FK__salesOrde__compa__1DE57479];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[contactPerson]', 'U') IS NOT NULL
    DROP TABLE [dbo].[contactPerson];
GO
IF OBJECT_ID(N'[dbo].[customers]', 'U') IS NOT NULL
    DROP TABLE [dbo].[customers];
GO
IF OBJECT_ID(N'[dbo].[deliveryOrder]', 'U') IS NOT NULL
    DROP TABLE [dbo].[deliveryOrder];
GO
IF OBJECT_ID(N'[dbo].[invo_ma]', 'U') IS NOT NULL
    DROP TABLE [dbo].[invo_ma];
GO
IF OBJECT_ID(N'[dbo].[invoice]', 'U') IS NOT NULL
    DROP TABLE [dbo].[invoice];
GO
IF OBJECT_ID(N'[dbo].[materials]', 'U') IS NOT NULL
    DROP TABLE [dbo].[materials];
GO
IF OBJECT_ID(N'[dbo].[orderForm]', 'U') IS NOT NULL
    DROP TABLE [dbo].[orderForm];
GO
IF OBJECT_ID(N'[dbo].[orderForm_ma]', 'U') IS NOT NULL
    DROP TABLE [dbo].[orderForm_ma];
GO
IF OBJECT_ID(N'[dbo].[out_ma]', 'U') IS NOT NULL
    DROP TABLE [dbo].[out_ma];
GO
IF OBJECT_ID(N'[dbo].[re_ven_ma]', 'U') IS NOT NULL
    DROP TABLE [dbo].[re_ven_ma];
GO
IF OBJECT_ID(N'[dbo].[rece_ma]', 'U') IS NOT NULL
    DROP TABLE [dbo].[rece_ma];
GO
IF OBJECT_ID(N'[dbo].[receipt]', 'U') IS NOT NULL
    DROP TABLE [dbo].[receipt];
GO
IF OBJECT_ID(N'[dbo].[requisition]', 'U') IS NOT NULL
    DROP TABLE [dbo].[requisition];
GO
IF OBJECT_ID(N'[dbo].[rfq]', 'U') IS NOT NULL
    DROP TABLE [dbo].[rfq];
GO
IF OBJECT_ID(N'[dbo].[rfq_ven_ma]', 'U') IS NOT NULL
    DROP TABLE [dbo].[rfq_ven_ma];
GO
IF OBJECT_ID(N'[dbo].[sales_ma]', 'U') IS NOT NULL
    DROP TABLE [dbo].[sales_ma];
GO
IF OBJECT_ID(N'[dbo].[salesOrder]', 'U') IS NOT NULL
    DROP TABLE [dbo].[salesOrder];
GO
IF OBJECT_ID(N'[dbo].[user]', 'U') IS NOT NULL
    DROP TABLE [dbo].[user];
GO
IF OBJECT_ID(N'[dbo].[vendor]', 'U') IS NOT NULL
    DROP TABLE [dbo].[vendor];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'contactPerson'
CREATE TABLE [dbo].[contactPerson] (
    [companyCode] int  NOT NULL,
    [contacnPersonID] int  NOT NULL,
    [department] nvarchar(20)  NULL,
    [gender] nvarchar(10)  NULL,
    [name] nvarchar(20)  NULL
);
GO

-- Creating table 'customers'
CREATE TABLE [dbo].[customers] (
    [companyCode] int  NOT NULL,
    [name] nvarchar(20)  NOT NULL,
    [country] nvarchar(20)  NOT NULL,
    [address] nvarchar(100)  NULL,
    [texRate] decimal(4,3)  NOT NULL
);
GO

-- Creating table 'deliveryOrder'
CREATE TABLE [dbo].[deliveryOrder] (
    [companyCode] int  NOT NULL,
    [salesOrder] int  NOT NULL,
    [deliveryOrderID] int  NOT NULL,
    [deliveryLocation] nvarchar(50)  NULL,
    [deliveryDate] datetime  NULL
);
GO

-- Creating table 'invo_ma'
CREATE TABLE [dbo].[invo_ma] (
    [companyCode] int  NOT NULL,
    [invoiceID] int  NOT NULL,
    [materialID] int  NOT NULL
);
GO

-- Creating table 'invoice'
CREATE TABLE [dbo].[invoice] (
    [companyCode] int  NOT NULL,
    [invoiceID] int  NOT NULL,
    [fiscalYear] int  NULL,
    [currency] nvarchar(20)  NULL,
    [amount] decimal(14,4)  NULL,
    [creationDate] datetime  NULL
);
GO

-- Creating table 'materials'
CREATE TABLE [dbo].[materials] (
    [materialID] int  NOT NULL,
    [vendorCode] int  NOT NULL,
    [name] nvarchar(20)  NULL,
    [quantity] int  NULL,
    [placeOfOrigin] nvarchar(20)  NULL,
    [describtion] nvarchar(100)  NULL,
    [unitPrice] decimal(10,4)  NULL,
    [discount] decimal(3,2)  NULL,
    [stock] int  NULL
);
GO

-- Creating table 'orderForm'
CREATE TABLE [dbo].[orderForm] (
    [vendorCode] int  NOT NULL,
    [orderFormID] int  NOT NULL,
    [rfqID] int  NOT NULL
);
GO

-- Creating table 'orderForm_ma'
CREATE TABLE [dbo].[orderForm_ma] (
    [rfqID] int  NOT NULL,
    [orderFormID] int  NOT NULL,
    [materialID] int  NOT NULL
);
GO

-- Creating table 'out_ma'
CREATE TABLE [dbo].[out_ma] (
    [salesOrderID] int  NOT NULL,
    [companyCode] int  NOT NULL,
    [deliveryOrderID] int  NOT NULL,
    [materialID] int  NOT NULL
);
GO

-- Creating table 're_ven_ma'
CREATE TABLE [dbo].[re_ven_ma] (
    [requisitionID] int  NOT NULL,
    [materialID] int  NOT NULL,
    [vendorCode] int  NOT NULL
);
GO

-- Creating table 'receipt'
CREATE TABLE [dbo].[receipt] (
    [vendorCode] int  NOT NULL,
    [receiptID] int  NOT NULL,
    [creationDate] datetime  NULL,
    [amount] decimal(14,4)  NULL
);
GO

-- Creating table 'requisition'
CREATE TABLE [dbo].[requisition] (
    [requisitionID] int  NOT NULL,
    [bidDate] datetime  NULL
);
GO

-- Creating table 'rfq'
CREATE TABLE [dbo].[rfq] (
    [rfqID] int  NOT NULL,
    [quotationDate] datetime  NULL,
    [creationDate] datetime  NULL
);
GO

-- Creating table 'rfq_ven_ma'
CREATE TABLE [dbo].[rfq_ven_ma] (
    [rfqID] int  NOT NULL,
    [vendorCode] int  NOT NULL,
    [materialID] int  NOT NULL
);
GO

-- Creating table 'sales_ma'
CREATE TABLE [dbo].[sales_ma] (
    [companyCode] int  NOT NULL,
    [salesOrderID] int  NOT NULL,
    [materialID] int  NOT NULL,
    [materialAmount] int  NULL
);
GO

-- Creating table 'salesOrder'
CREATE TABLE [dbo].[salesOrder] (
    [companyCode] int  NOT NULL,
    [salesOrderID] int  NOT NULL,
    [amount] decimal(14,4)  NOT NULL,
    [paymentDate] datetime  NULL
);
GO

-- Creating table 'user'
CREATE TABLE [dbo].[user] (
    [Id] int  NOT NULL,
    [Username] nvarchar(50)  NULL,
    [Password] nvarchar(50)  NULL,
    [Gender] nvarchar(10)  NULL,
    [Name] nvarchar(50)  NULL,
    [Email] nvarchar(50)  NULL,
    [Tel] nvarchar(20)  NULL,
    [Type] nvarchar(10)  NULL
);
GO

-- Creating table 'vendor'
CREATE TABLE [dbo].[vendor] (
    [vendorCode] int  NOT NULL,
    [name] nvarchar(20)  NULL,
    [location] nvarchar(50)  NULL,
    [currency] nvarchar(20)  NULL,
    [taxRate] decimal(4,3)  NULL
);
GO

-- Creating table 'rece_ma'
CREATE TABLE [dbo].[rece_ma] (
    [materials_materialID] int  NOT NULL,
    [receipt_receiptID] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [contacnPersonID] in table 'contactPerson'
ALTER TABLE [dbo].[contactPerson]
ADD CONSTRAINT [PK_contactPerson]
    PRIMARY KEY CLUSTERED ([contacnPersonID] ASC);
GO

-- Creating primary key on [companyCode] in table 'customers'
ALTER TABLE [dbo].[customers]
ADD CONSTRAINT [PK_customers]
    PRIMARY KEY CLUSTERED ([companyCode] ASC);
GO

-- Creating primary key on [deliveryOrderID] in table 'deliveryOrder'
ALTER TABLE [dbo].[deliveryOrder]
ADD CONSTRAINT [PK_deliveryOrder]
    PRIMARY KEY CLUSTERED ([deliveryOrderID] ASC);
GO

-- Creating primary key on [invoiceID], [materialID] in table 'invo_ma'
ALTER TABLE [dbo].[invo_ma]
ADD CONSTRAINT [PK_invo_ma]
    PRIMARY KEY CLUSTERED ([invoiceID], [materialID] ASC);
GO

-- Creating primary key on [invoiceID] in table 'invoice'
ALTER TABLE [dbo].[invoice]
ADD CONSTRAINT [PK_invoice]
    PRIMARY KEY CLUSTERED ([invoiceID] ASC);
GO

-- Creating primary key on [materialID] in table 'materials'
ALTER TABLE [dbo].[materials]
ADD CONSTRAINT [PK_materials]
    PRIMARY KEY CLUSTERED ([materialID] ASC);
GO

-- Creating primary key on [orderFormID] in table 'orderForm'
ALTER TABLE [dbo].[orderForm]
ADD CONSTRAINT [PK_orderForm]
    PRIMARY KEY CLUSTERED ([orderFormID] ASC);
GO

-- Creating primary key on [orderFormID], [materialID] in table 'orderForm_ma'
ALTER TABLE [dbo].[orderForm_ma]
ADD CONSTRAINT [PK_orderForm_ma]
    PRIMARY KEY CLUSTERED ([orderFormID], [materialID] ASC);
GO

-- Creating primary key on [deliveryOrderID], [materialID] in table 'out_ma'
ALTER TABLE [dbo].[out_ma]
ADD CONSTRAINT [PK_out_ma]
    PRIMARY KEY CLUSTERED ([deliveryOrderID], [materialID] ASC);
GO

-- Creating primary key on [requisitionID], [materialID] in table 're_ven_ma'
ALTER TABLE [dbo].[re_ven_ma]
ADD CONSTRAINT [PK_re_ven_ma]
    PRIMARY KEY CLUSTERED ([requisitionID], [materialID] ASC);
GO

-- Creating primary key on [receiptID] in table 'receipt'
ALTER TABLE [dbo].[receipt]
ADD CONSTRAINT [PK_receipt]
    PRIMARY KEY CLUSTERED ([receiptID] ASC);
GO

-- Creating primary key on [requisitionID] in table 'requisition'
ALTER TABLE [dbo].[requisition]
ADD CONSTRAINT [PK_requisition]
    PRIMARY KEY CLUSTERED ([requisitionID] ASC);
GO

-- Creating primary key on [rfqID] in table 'rfq'
ALTER TABLE [dbo].[rfq]
ADD CONSTRAINT [PK_rfq]
    PRIMARY KEY CLUSTERED ([rfqID] ASC);
GO

-- Creating primary key on [rfqID], [vendorCode], [materialID] in table 'rfq_ven_ma'
ALTER TABLE [dbo].[rfq_ven_ma]
ADD CONSTRAINT [PK_rfq_ven_ma]
    PRIMARY KEY CLUSTERED ([rfqID], [vendorCode], [materialID] ASC);
GO

-- Creating primary key on [salesOrderID], [materialID] in table 'sales_ma'
ALTER TABLE [dbo].[sales_ma]
ADD CONSTRAINT [PK_sales_ma]
    PRIMARY KEY CLUSTERED ([salesOrderID], [materialID] ASC);
GO

-- Creating primary key on [salesOrderID] in table 'salesOrder'
ALTER TABLE [dbo].[salesOrder]
ADD CONSTRAINT [PK_salesOrder]
    PRIMARY KEY CLUSTERED ([salesOrderID] ASC);
GO

-- Creating primary key on [Id] in table 'user'
ALTER TABLE [dbo].[user]
ADD CONSTRAINT [PK_user]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [vendorCode] in table 'vendor'
ALTER TABLE [dbo].[vendor]
ADD CONSTRAINT [PK_vendor]
    PRIMARY KEY CLUSTERED ([vendorCode] ASC);
GO

-- Creating primary key on [materials_materialID], [receipt_receiptID] in table 'rece_ma'
ALTER TABLE [dbo].[rece_ma]
ADD CONSTRAINT [PK_rece_ma]
    PRIMARY KEY NONCLUSTERED ([materials_materialID], [receipt_receiptID] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [companyCode] in table 'contactPerson'
ALTER TABLE [dbo].[contactPerson]
ADD CONSTRAINT [FK__contactPe__compa__145C0A3F]
    FOREIGN KEY ([companyCode])
    REFERENCES [dbo].[customers]
        ([companyCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__contactPe__compa__145C0A3F'
CREATE INDEX [IX_FK__contactPe__compa__145C0A3F]
ON [dbo].[contactPerson]
    ([companyCode]);
GO

-- Creating foreign key on [companyCode] in table 'deliveryOrder'
ALTER TABLE [dbo].[deliveryOrder]
ADD CONSTRAINT [FK__deliveryO__compa__21B6055D]
    FOREIGN KEY ([companyCode])
    REFERENCES [dbo].[customers]
        ([companyCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__deliveryO__compa__21B6055D'
CREATE INDEX [IX_FK__deliveryO__compa__21B6055D]
ON [dbo].[deliveryOrder]
    ([companyCode]);
GO

-- Creating foreign key on [companyCode] in table 'invo_ma'
ALTER TABLE [dbo].[invo_ma]
ADD CONSTRAINT [FK__invo_ma__company__4D94879B]
    FOREIGN KEY ([companyCode])
    REFERENCES [dbo].[customers]
        ([companyCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__invo_ma__company__4D94879B'
CREATE INDEX [IX_FK__invo_ma__company__4D94879B]
ON [dbo].[invo_ma]
    ([companyCode]);
GO

-- Creating foreign key on [companyCode] in table 'invoice'
ALTER TABLE [dbo].[invoice]
ADD CONSTRAINT [FK__invoice__company__25869641]
    FOREIGN KEY ([companyCode])
    REFERENCES [dbo].[customers]
        ([companyCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__invoice__company__25869641'
CREATE INDEX [IX_FK__invoice__company__25869641]
ON [dbo].[invoice]
    ([companyCode]);
GO

-- Creating foreign key on [companyCode] in table 'out_ma'
ALTER TABLE [dbo].[out_ma]
ADD CONSTRAINT [FK__out_ma__companyC__48CFD27E]
    FOREIGN KEY ([companyCode])
    REFERENCES [dbo].[customers]
        ([companyCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__out_ma__companyC__48CFD27E'
CREATE INDEX [IX_FK__out_ma__companyC__48CFD27E]
ON [dbo].[out_ma]
    ([companyCode]);
GO

-- Creating foreign key on [companyCode] in table 'sales_ma'
ALTER TABLE [dbo].[sales_ma]
ADD CONSTRAINT [FK__sales_ma__compan__4222D4EF]
    FOREIGN KEY ([companyCode])
    REFERENCES [dbo].[customers]
        ([companyCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__sales_ma__compan__4222D4EF'
CREATE INDEX [IX_FK__sales_ma__compan__4222D4EF]
ON [dbo].[sales_ma]
    ([companyCode]);
GO

-- Creating foreign key on [companyCode] in table 'salesOrder'
ALTER TABLE [dbo].[salesOrder]
ADD CONSTRAINT [FK__salesOrde__compa__1DE57479]
    FOREIGN KEY ([companyCode])
    REFERENCES [dbo].[customers]
        ([companyCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__salesOrde__compa__1DE57479'
CREATE INDEX [IX_FK__salesOrde__compa__1DE57479]
ON [dbo].[salesOrder]
    ([companyCode]);
GO

-- Creating foreign key on [salesOrder] in table 'deliveryOrder'
ALTER TABLE [dbo].[deliveryOrder]
ADD CONSTRAINT [FK__deliveryO__sales__22AA2996]
    FOREIGN KEY ([salesOrder])
    REFERENCES [dbo].[salesOrder]
        ([salesOrderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__deliveryO__sales__22AA2996'
CREATE INDEX [IX_FK__deliveryO__sales__22AA2996]
ON [dbo].[deliveryOrder]
    ([salesOrder]);
GO

-- Creating foreign key on [deliveryOrderID] in table 'out_ma'
ALTER TABLE [dbo].[out_ma]
ADD CONSTRAINT [FK__out_ma__delivery__49C3F6B7]
    FOREIGN KEY ([deliveryOrderID])
    REFERENCES [dbo].[deliveryOrder]
        ([deliveryOrderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [invoiceID] in table 'invo_ma'
ALTER TABLE [dbo].[invo_ma]
ADD CONSTRAINT [FK__invo_ma__invoice__4E88ABD4]
    FOREIGN KEY ([invoiceID])
    REFERENCES [dbo].[invoice]
        ([invoiceID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [materialID] in table 'invo_ma'
ALTER TABLE [dbo].[invo_ma]
ADD CONSTRAINT [FK__invo_ma__materia__4F7CD00D]
    FOREIGN KEY ([materialID])
    REFERENCES [dbo].[materials]
        ([materialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__invo_ma__materia__4F7CD00D'
CREATE INDEX [IX_FK__invo_ma__materia__4F7CD00D]
ON [dbo].[invo_ma]
    ([materialID]);
GO

-- Creating foreign key on [vendorCode] in table 'materials'
ALTER TABLE [dbo].[materials]
ADD CONSTRAINT [FK__materials__vendo__34C8D9D1]
    FOREIGN KEY ([vendorCode])
    REFERENCES [dbo].[vendor]
        ([vendorCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__materials__vendo__34C8D9D1'
CREATE INDEX [IX_FK__materials__vendo__34C8D9D1]
ON [dbo].[materials]
    ([vendorCode]);
GO

-- Creating foreign key on [materialID] in table 'orderForm_ma'
ALTER TABLE [dbo].[orderForm_ma]
ADD CONSTRAINT [FK__orderForm__mater__5DCAEF64]
    FOREIGN KEY ([materialID])
    REFERENCES [dbo].[materials]
        ([materialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__orderForm__mater__5DCAEF64'
CREATE INDEX [IX_FK__orderForm__mater__5DCAEF64]
ON [dbo].[orderForm_ma]
    ([materialID]);
GO

-- Creating foreign key on [materialID] in table 'out_ma'
ALTER TABLE [dbo].[out_ma]
ADD CONSTRAINT [FK__out_ma__material__4AB81AF0]
    FOREIGN KEY ([materialID])
    REFERENCES [dbo].[materials]
        ([materialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__out_ma__material__4AB81AF0'
CREATE INDEX [IX_FK__out_ma__material__4AB81AF0]
ON [dbo].[out_ma]
    ([materialID]);
GO

-- Creating foreign key on [materialID] in table 're_ven_ma'
ALTER TABLE [dbo].[re_ven_ma]
ADD CONSTRAINT [FK__re_ven_ma__mater__534D60F1]
    FOREIGN KEY ([materialID])
    REFERENCES [dbo].[materials]
        ([materialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__re_ven_ma__mater__534D60F1'
CREATE INDEX [IX_FK__re_ven_ma__mater__534D60F1]
ON [dbo].[re_ven_ma]
    ([materialID]);
GO

-- Creating foreign key on [materialID] in table 'rfq_ven_ma'
ALTER TABLE [dbo].[rfq_ven_ma]
ADD CONSTRAINT [FK__rfq_ven_m__mater__59063A47]
    FOREIGN KEY ([materialID])
    REFERENCES [dbo].[materials]
        ([materialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__rfq_ven_m__mater__59063A47'
CREATE INDEX [IX_FK__rfq_ven_m__mater__59063A47]
ON [dbo].[rfq_ven_ma]
    ([materialID]);
GO

-- Creating foreign key on [materialID] in table 'sales_ma'
ALTER TABLE [dbo].[sales_ma]
ADD CONSTRAINT [FK__sales_ma__materi__44FF419A]
    FOREIGN KEY ([materialID])
    REFERENCES [dbo].[materials]
        ([materialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__sales_ma__materi__44FF419A'
CREATE INDEX [IX_FK__sales_ma__materi__44FF419A]
ON [dbo].[sales_ma]
    ([materialID]);
GO

-- Creating foreign key on [orderFormID] in table 'orderForm_ma'
ALTER TABLE [dbo].[orderForm_ma]
ADD CONSTRAINT [FK__orderForm__order__5CD6CB2B]
    FOREIGN KEY ([orderFormID])
    REFERENCES [dbo].[orderForm]
        ([orderFormID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [rfqID] in table 'orderForm'
ALTER TABLE [dbo].[orderForm]
ADD CONSTRAINT [FK__orderForm__rfqID__2F10007B]
    FOREIGN KEY ([rfqID])
    REFERENCES [dbo].[rfq]
        ([rfqID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__orderForm__rfqID__2F10007B'
CREATE INDEX [IX_FK__orderForm__rfqID__2F10007B]
ON [dbo].[orderForm]
    ([rfqID]);
GO

-- Creating foreign key on [vendorCode] in table 'orderForm'
ALTER TABLE [dbo].[orderForm]
ADD CONSTRAINT [FK__orderForm__vendo__2E1BDC42]
    FOREIGN KEY ([vendorCode])
    REFERENCES [dbo].[vendor]
        ([vendorCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__orderForm__vendo__2E1BDC42'
CREATE INDEX [IX_FK__orderForm__vendo__2E1BDC42]
ON [dbo].[orderForm]
    ([vendorCode]);
GO

-- Creating foreign key on [rfqID] in table 'orderForm_ma'
ALTER TABLE [dbo].[orderForm_ma]
ADD CONSTRAINT [FK__orderForm__rfqID__5BE2A6F2]
    FOREIGN KEY ([rfqID])
    REFERENCES [dbo].[rfq]
        ([rfqID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__orderForm__rfqID__5BE2A6F2'
CREATE INDEX [IX_FK__orderForm__rfqID__5BE2A6F2]
ON [dbo].[orderForm_ma]
    ([rfqID]);
GO

-- Creating foreign key on [salesOrderID] in table 'out_ma'
ALTER TABLE [dbo].[out_ma]
ADD CONSTRAINT [FK__out_ma__salesOrd__47DBAE45]
    FOREIGN KEY ([salesOrderID])
    REFERENCES [dbo].[salesOrder]
        ([salesOrderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__out_ma__salesOrd__47DBAE45'
CREATE INDEX [IX_FK__out_ma__salesOrd__47DBAE45]
ON [dbo].[out_ma]
    ([salesOrderID]);
GO

-- Creating foreign key on [requisitionID] in table 're_ven_ma'
ALTER TABLE [dbo].[re_ven_ma]
ADD CONSTRAINT [FK__re_ven_ma__requi__52593CB8]
    FOREIGN KEY ([requisitionID])
    REFERENCES [dbo].[requisition]
        ([requisitionID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [vendorCode] in table 're_ven_ma'
ALTER TABLE [dbo].[re_ven_ma]
ADD CONSTRAINT [FK__re_ven_ma__vendo__5441852A]
    FOREIGN KEY ([vendorCode])
    REFERENCES [dbo].[vendor]
        ([vendorCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__re_ven_ma__vendo__5441852A'
CREATE INDEX [IX_FK__re_ven_ma__vendo__5441852A]
ON [dbo].[re_ven_ma]
    ([vendorCode]);
GO

-- Creating foreign key on [vendorCode] in table 'receipt'
ALTER TABLE [dbo].[receipt]
ADD CONSTRAINT [FK__receipt__vendorC__31EC6D26]
    FOREIGN KEY ([vendorCode])
    REFERENCES [dbo].[vendor]
        ([vendorCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__receipt__vendorC__31EC6D26'
CREATE INDEX [IX_FK__receipt__vendorC__31EC6D26]
ON [dbo].[receipt]
    ([vendorCode]);
GO

-- Creating foreign key on [rfqID] in table 'rfq_ven_ma'
ALTER TABLE [dbo].[rfq_ven_ma]
ADD CONSTRAINT [FK__rfq_ven_m__rfqID__571DF1D5]
    FOREIGN KEY ([rfqID])
    REFERENCES [dbo].[rfq]
        ([rfqID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [vendorCode] in table 'rfq_ven_ma'
ALTER TABLE [dbo].[rfq_ven_ma]
ADD CONSTRAINT [FK__rfq_ven_m__vendo__5812160E]
    FOREIGN KEY ([vendorCode])
    REFERENCES [dbo].[vendor]
        ([vendorCode])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK__rfq_ven_m__vendo__5812160E'
CREATE INDEX [IX_FK__rfq_ven_m__vendo__5812160E]
ON [dbo].[rfq_ven_ma]
    ([vendorCode]);
GO

-- Creating foreign key on [salesOrderID] in table 'sales_ma'
ALTER TABLE [dbo].[sales_ma]
ADD CONSTRAINT [FK__sales_ma__salesO__440B1D61]
    FOREIGN KEY ([salesOrderID])
    REFERENCES [dbo].[salesOrder]
        ([salesOrderID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [materials_materialID] in table 'rece_ma'
ALTER TABLE [dbo].[rece_ma]
ADD CONSTRAINT [FK_rece_ma_materials]
    FOREIGN KEY ([materials_materialID])
    REFERENCES [dbo].[materials]
        ([materialID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [receipt_receiptID] in table 'rece_ma'
ALTER TABLE [dbo].[rece_ma]
ADD CONSTRAINT [FK_rece_ma_receipt]
    FOREIGN KEY ([receipt_receiptID])
    REFERENCES [dbo].[receipt]
        ([receiptID])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_rece_ma_receipt'
CREATE INDEX [IX_FK_rece_ma_receipt]
ON [dbo].[rece_ma]
    ([receipt_receiptID]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------