﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP_System.MMModule
{
    class Material_Check
    {
        private Db_Operate DataBase_Operate; //db related var.
        private materials Materials;

        public Material_Check()
        {
            DataBase_Operate = new Db_Operate();
        }

        public List<string> GetMaterialsID()
        {
            //get materilas ID 
            return DataBase_Operate.Materials_GetMaterialsID();
        }
        public List<string> GetSelectedMaterialsInfo(int selected)
        {
            //get Selected materials infomation
            return DataBase_Operate.Materials_GetSelectedMaterialsInfo(selected);
        }

    }
}
