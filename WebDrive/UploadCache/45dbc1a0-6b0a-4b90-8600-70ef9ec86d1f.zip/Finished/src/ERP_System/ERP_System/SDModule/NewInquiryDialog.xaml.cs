﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System.SDModule
{
    /// <summary>
    /// NewInquiryDialog.xaml 的互動邏輯
    /// </summary>
    public partial class NewInquiryDialog : Window
    {
        System.Data.DataRowView MaterialNumRecoder = new System.Data.DataRowView();
        ERP_DBEntities db = new ERP_DBEntities();
        String SelectMaterialName = "null";
        int SelectMaterialPrice = 0;

        public NewInquiryDialog(int selectedCustomerCode, int inquiryID)
        {
            InitializeComponent();
            var findInquiryIDQuery = from d in db.inquiry where d.inquiryID == inquiryID select d.inquiryID;
            
            if (findInquiryIDQuery.ToList().Count() != 0)
            {
                MessageBox.Show("询价单号重复！", "错误！");
                this.Close();
                return;
            }

            CustomerCodeTextBox.Text = selectedCustomerCode.ToString();
            //materialsDataGrid.CanUserAddRows = false;
            //materialsDataGrid.CanUserDeleteRows = false;
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {

            ERP_System.ERP_DBDataSet eRP_DBDataSet = ((ERP_System.ERP_DBDataSet)(this.FindResource("eRP_DBDataSet")));
            // 将数据加载到表 materials 中。可以根据需要修改此代码。
            ERP_System.ERP_DBDataSetTableAdapters.materialsTableAdapter eRP_DBDataSetmaterialsTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.materialsTableAdapter();
            eRP_DBDataSetmaterialsTableAdapter.Fill(eRP_DBDataSet.materials);
            System.Windows.Data.CollectionViewSource materialsViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("materialsViewSource")));
            materialsViewSource.View.MoveCurrentToFirst();
        }

        private void materialsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void SaveButton_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            var b = (System.Data.DataRowView)MaNameComboBox.SelectedItem;
            Console.WriteLine((String)b["name"]);
            SelectMaterialName = (String)b["name"];
            var getPriceQuery = from d in db.materials where d.name == SelectMaterialName select d.unitPrice;
            PriceTextBox.Text = getPriceQuery.First().ToString();
            SelectMaterialPrice = int.Parse(getPriceQuery.First().ToString());

        }

        private void AmountTextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            if (SelectMaterialName != "null")
            {
                int amount = 0;
                try
                {
                    amount = int.Parse(AmountTextBox.Text.ToString());
                }
                catch
                {

                }
                TotalPriceTextBox.Text = (SelectMaterialPrice * amount).ToString();
            }
        }

    }
}
