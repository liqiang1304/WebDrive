﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System.SDModule
{
    /// <summary>
    /// NewSalesOrderDialog.xaml 的互動邏輯
    /// </summary>
    public partial class NewSalesOrderDialog : Window
    {
        private String SelectMaterialName = "null";
        private ERP_DBEntities db = new ERP_DBEntities();
        private float SelectMaterialPrice = 0;
        private float totalPrice = 0;
        private System.Collections.Hashtable materialNum = new System.Collections.Hashtable();
        private System.Collections.Hashtable materialPrice = new System.Collections.Hashtable();
        private System.Collections.Hashtable materialDiscount = new System.Collections.Hashtable();
        //to map the material name and some property
        private int getCustomerCode;
        private int getSalesOrderID;
        private String getCustomerName;


        public NewSalesOrderDialog(String customerName, int CustomerID, int SalesOrderID)
        {
            InitializeComponent();
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
            var findOrderIDQuery = from d in db.salesOrder where d.salesOrderID == SalesOrderID select d.salesOrderID;
            //to find is ID repeat?
            if (findOrderIDQuery.ToList().Count() != 0)
            {
                MessageBox.Show("询价单号重复！", "错误！");
                this.Close();
                return;
            }

            CustomerNameTextBox.Text = customerName;
            OrderDataTextBox.Text = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            getCustomerCode = CustomerID;
            getCustomerName = customerName;
            getSalesOrderID = SalesOrderID;
            //init;
            
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            //realod datagrid
            ERP_System.ERP_DBDataSet eRP_DBDataSet = ((ERP_System.ERP_DBDataSet)(this.FindResource("eRP_DBDataSet")));
            // 将数据加载到表 materials 中。可以根据需要修改此代码。
            ERP_System.ERP_DBDataSetTableAdapters.materialsTableAdapter eRP_DBDataSetmaterialsTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.materialsTableAdapter();
            eRP_DBDataSetmaterialsTableAdapter.Fill(eRP_DBDataSet.materials);
            System.Windows.Data.CollectionViewSource materialsViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("materialsViewSource")));
            materialsViewSource.View.MoveCurrentToFirst();
        }

        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            var selectMaterials = (System.Data.DataRowView)SelectMaterialsComboBox.SelectedItem;
            SelectMaterialName = (String)selectMaterials["name"];

            var getPriceQuery = from d in db.materials where d.name == SelectMaterialName select d.unitPrice;
            PriceTextBox.Text = getPriceQuery.First().ToString();
            SelectMaterialPrice = float.Parse(getPriceQuery.First().ToString());
            var getDiscountQuery = from d in db.materials where d.name == SelectMaterialName select d.discount;
            //if combobox changed then relaod price and totoal price 

            if (!materialPrice.Contains(SelectMaterialName))
            {
                try
                {
                    float materialsPrice = float.Parse(getPriceQuery.First().ToString());
                    float discount = float.Parse(getDiscountQuery.First().ToString());
                    materialPrice.Add(SelectMaterialName, materialsPrice);
                    materialDiscount.Add(SelectMaterialName, discount);
                    //to add some property to map.
                }
                catch
                {

                }
            }

            if (materialNum.Contains(SelectMaterialName))
            {
                AmountTextBox.Text = materialNum[SelectMaterialName].ToString();
            }
            else
            {
                AmountTextBox.Text = "0";
            }
        }

        private void AmountTextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            //when material nubmers changed, the total price is needs to change
            int amount = 0;
            if (SelectMaterialName != "null")
            {
                try
                {
                    if (AmountTextBox.Text != "")
                       amount = int.Parse(AmountTextBox.Text.ToString());
                }
                catch
                {
                    //to correct the input
                    AmountTextBox.Text = "";
                    MessageBox.Show("请填写数字", "错误！");
                    return;
                }
                totalPrice = SelectMaterialPrice * amount;
                TotalPriceTextBox.Text = totalPrice.ToString();
                if (materialNum.Contains(SelectMaterialName))
                {
                    materialNum[SelectMaterialName] = amount;
                }
                else
                {
                    materialNum.Add(SelectMaterialName, amount);
                }
            }
        }

        private void CancleButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            //to calc to total price 
            float totalAmount = 0;
            foreach (System.Collections.DictionaryEntry de in materialNum)
            {
                Console.WriteLine(de.Key);
                Console.WriteLine(de.Value);
                totalAmount = totalAmount + (int)de.Value * (float)materialPrice[(String)de.Key] * (float)materialDiscount[(String)de.Key];
            }
            salesOrder addSalesOrder = new salesOrder()
            {
                companyCode = getCustomerCode,
                salesOrderID = getSalesOrderID,
                paymentDate = System.DateTime.Now,
                amount = (decimal)totalAmount
            };
            try
            {
                //to add a general order to sales order table;
                db.salesOrder.Add(addSalesOrder);
                db.SaveChanges();
            }
            catch
            {
                db.salesOrder.Remove(addSalesOrder);
                MessageBox.Show("数据库访问错误！", "错误！");
                return;
            }

            foreach (System.Collections.DictionaryEntry de in materialNum)
            {
                //to add each materals to sale_ma table;
                if ((int)de.Value == 0) continue;
                var getIDQuery = from d in db.materials where d.name == (String)de.Key select d.materialID;
                int maID = (int)getIDQuery.First();

                sales_ma addSales_ma = new sales_ma()
                {
                    companyCode = getCustomerCode,
                    salesOrderID = getSalesOrderID,
                    materialID = maID,
                    materialAmount = (int)de.Value
                };
                try
                {
                    db.sales_ma.Add(addSales_ma);
                    db.SaveChanges();
                }
                catch
                {
                    MessageBox.Show("数据库访问错误！", "错误！");
                    return;
                }
            }

            this.Close();
        }
    }
}
