﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System.SDModule
{
    /// <summary>
    /// ViewDeliveryOrderDialog.xaml 的互動邏輯
    /// </summary>
    public partial class ViewDeliveryOrderDialog : Window
    {
        public ViewDeliveryOrderDialog()
        {
            InitializeComponent();
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {

            ERP_System.ERP_DBDataSet eRP_DBDataSet = ((ERP_System.ERP_DBDataSet)(this.FindResource("eRP_DBDataSet")));
            // 将数据加载到表 deliveryOrder 中。可以根据需要修改此代码。
            ERP_System.ERP_DBDataSetTableAdapters.deliveryOrderTableAdapter eRP_DBDataSetdeliveryOrderTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.deliveryOrderTableAdapter();
            eRP_DBDataSetdeliveryOrderTableAdapter.Fill(eRP_DBDataSet.deliveryOrder);
            System.Windows.Data.CollectionViewSource deliveryOrderViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("deliveryOrderViewSource")));
            deliveryOrderViewSource.View.MoveCurrentToFirst();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
