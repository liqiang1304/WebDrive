﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP_System.SDModule
{
    /// <summary>
    /// SDWindow.xaml 的互動邏輯
    /// </summary>
    public partial class SDWindow : Window
    {
        private ERP_DBEntities db;
        private int selectedCustomerCode = -1;//in New contact person page, recode which customer need to add contact person, if not set it to -1
        private CheckTextBox checkTextBox = new CheckTextBox();

        public SDWindow()
        {
            InitializeComponent();
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
            db = new ERP_DBEntities();
        }

        private void CompanyCodeTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void NewCustomerSaveButton_Click(object sender, RoutedEventArgs e)
        {
            AddCustomer addCustomer = new AddCustomer();
            int returnType = addCustomer.add(CompanyCodeTextBox.Text, CompanyNameTextBox.Text, AddressTextBox.Text, TexRateTextBox.Text, CountryTextBox.Text);
            if (returnType == 0)
            {
                MessageBox.Show("已新增客户：" + CompanyNameTextBox.Text.ToString(), "新增客户成功！", MessageBoxButton.OK, MessageBoxImage.Information);
                ClearAllAddCustomerContent();
            }
            else if (returnType == 1)
            {
                MessageBox.Show("您的输入有误，请重新输入！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else if (returnType == 2)
            {
                MessageBox.Show("数据库写入异常！", "新增客户失败！", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void NewCustomerClearButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("是否清空所填内容？", "警告！", MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes)
            {
                ClearAllAddCustomerContent();
                //click clear button to clear all the textbox;
            }
        }

        private void ClearAllAddCustomerContent()
        {
            CompanyCodeTextBox.Text = "";
            CompanyNameTextBox.Text = "";
            AddressTextBox.Text = "";
            TexRateTextBox.Text = "";
            CountryTextBox.Text = "";
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            reload_EditDataGrid();
            ERP_System.ERP_DBDataSet eRP_DBDataSet = ((ERP_System.ERP_DBDataSet)(this.FindResource("eRP_DBDataSet")));
            // 将数据加载到表 materials 中。可以根据需要修改此代码。
            ERP_System.ERP_DBDataSetTableAdapters.materialsTableAdapter eRP_DBDataSetmaterialsTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.materialsTableAdapter();
            eRP_DBDataSetmaterialsTableAdapter.Fill(eRP_DBDataSet.materials);
            System.Windows.Data.CollectionViewSource materialsViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("materialsViewSource")));
            materialsViewSource.View.MoveCurrentToFirst();
            // 将数据加载到表 salesOrder 中。可以根据需要修改此代码。
            ERP_System.ERP_DBDataSetTableAdapters.salesOrderTableAdapter eRP_DBDataSetsalesOrderTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.salesOrderTableAdapter();
            eRP_DBDataSetsalesOrderTableAdapter.Fill(eRP_DBDataSet.salesOrder);
            System.Windows.Data.CollectionViewSource salesOrderViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("salesOrderViewSource")));
            salesOrderViewSource.View.MoveCurrentToFirst();
            // 将数据加载到表 sales_ma 中。可以根据需要修改此代码。
            ERP_System.ERP_DBDataSetTableAdapters.sales_maTableAdapter eRP_DBDataSetsales_maTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.sales_maTableAdapter();
            eRP_DBDataSetsales_maTableAdapter.Fill(eRP_DBDataSet.sales_ma);
            System.Windows.Data.CollectionViewSource sales_maViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("sales_maViewSource")));
            sales_maViewSource.View.MoveCurrentToFirst();
        }

        private void reload_EditDataGrid()
        {
            ERP_System.ERP_DBDataSet eRP_DBDataSet = ((ERP_System.ERP_DBDataSet)(this.FindResource("eRP_DBDataSet")));
            // 将数据加载到表 contactPerson 中。可以根据需要修改此代码。
            ERP_System.ERP_DBDataSetTableAdapters.contactPersonTableAdapter eRP_DBDataSetcontactPersonTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.contactPersonTableAdapter();

            if (selectedCustomerCode != -1)
                eRP_DBDataSetcontactPersonTableAdapter.FillByCode(eRP_DBDataSet.contactPerson, selectedCustomerCode);
            //fill the contactPersonDataGrid use binding data which is speical customercode;

            System.Windows.Data.CollectionViewSource contactPersonViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("contactPersonViewSource")));
            contactPersonViewSource.View.MoveCurrentToFirst();
        }

        private void ChoseCustomerButton_Click(object sender, RoutedEventArgs e)
        {
            BrowseCustomerDialog browseCustomerDialog = new BrowseCustomerDialog();
            browseCustomerDialog.selectedCustomer += new selectedCustomerHandler(ChoseCustomerChanged);
            //this is a handler in BrowseCustomerDialog and pass a func ChoseCustomerChanged to it.
            browseCustomerDialog.ShowDialog();
        }

        void ChoseCustomerChanged(String selectedCustomerName, int selectedCustomerCode)
        {
            ChoseCustomerCodeTextBox.Text = selectedCustomerCode.ToString();
            ChoseCustomerNameTextBox.Text = selectedCustomerName;
            SaleCustomerCodeTextBox.Text = selectedCustomerCode.ToString();
            SaleCustomerNameTextBox.Text = selectedCustomerName;

            this.selectedCustomerCode = selectedCustomerCode;
            //when user select another customer to display it's contact person, it need to chang costomer id and name in add contact person page.
            reload_EditDataGrid();
            //reload datagrid to refresh data selected.
            contactPersonDataGrid.UpdateLayout();
        }

        private void NewContactPerson_Click(object sender, RoutedEventArgs e)
        {
            NewContactPersonDialog newContactPersonDialog = new NewContactPersonDialog(ChoseCustomerNameTextBox.Text, selectedCustomerCode);
            try
            {
                newContactPersonDialog.ShowDialog();
            }
            catch
            {
                Console.WriteLine("can't open the dialog because there is not matching conditions");
            }
            newContactPersonDialog.closeDialogEvent += new CloseDialogEvent(reload_EditDataGrid);
            //a handler to pass a func reload_EditDataGrid, when add a new contact person, the page refresh the datagrid of contact person.
        }

        private void RefreshContactPersonButton_Click(object sender, RoutedEventArgs e)
        {
            reload_EditDataGrid();
        }

        private void BrowseCustomerDataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void DeleteContactPerson_Click(object sender, RoutedEventArgs e)
        {

            var selectRow = (System.Data.DataRowView)contactPersonDataGrid.SelectedItem;
            int icontactPersonID = (int)selectRow["contacnPersonID"];
            //to identify slected row data in contact datagrid, and find it's person id.
            contactPerson deleteContactPerson = db.contactPerson.First(c => c.contacnPersonID == icontactPersonID);
            //delete contact person linq
            db.contactPerson.Remove(deleteContactPerson);
            db.SaveChanges();
            reload_EditDataGrid();
            //reload datagrid.
        }


        private void SelectSaleOrderCustomerButton_Click(object sender, RoutedEventArgs e)
        {
            BrowseCustomerDialog browseCustomerDialog = new BrowseCustomerDialog();
            browseCustomerDialog.selectedCustomer += new selectedCustomerHandler(ChoseCustomerChanged);
            //this is a handler in BrowseCustomerDialog and pass a func ChoseCustomerChanged to it.
            browseCustomerDialog.ShowDialog();
        }

        private void AddSalesOrderButton_Click(object sender, RoutedEventArgs e)
        {
            int SalesOrderID = -1;
            try
            {
                SalesOrderID = int.Parse(SalesOrderIDTextBox.Text);
            }catch
            {
                MessageBox.Show("请输入正确的订单号！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (SalesOrderID != -1 && selectedCustomerCode != -1)
            {
                NewSalesOrderDialog newSalesOrderDialog = new NewSalesOrderDialog(SaleCustomerNameTextBox.Text, selectedCustomerCode, SalesOrderID);
                try
                {
                    newSalesOrderDialog.ShowDialog();
                }
                catch
                {
                    //dialog will closed if some error happend,so catch it.
                }

            }
            if (selectedCustomerCode == -1)
            {
                MessageBox.Show("请先选择正确的客户！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ViewSalesOrderButton_Click(object sender, RoutedEventArgs e)
        {
            ViewSalesOrderDialog viewSalesOrderDialog = new ViewSalesOrderDialog();
            viewSalesOrderDialog.ShowDialog();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ViewDeliveryOrderDialog viewDeliveryOrderDialog = new ViewDeliveryOrderDialog();
            viewDeliveryOrderDialog.ShowDialog();
        }

        private void CreatDeliveryButton_Click(object sender, RoutedEventArgs e)
        {
            int deliveryID = -1;
            try
            {
                deliveryID = int.Parse(DeliveryOrderIDTextBox.Text);
            }catch{
                // to catch the error ID;
                MessageBox.Show("请输入正确的递送单号！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (deliveryID >= 0)
            {
                NewDeliveryDialog newDeliveryDiaog = new NewDeliveryDialog(deliveryID);
                try
                {
                    newDeliveryDiaog.ShowDialog();
                }
                catch
                {
                    //dialog will closed if some error happend,so catch it.
                }
            }

        }

        private void SDTabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void AddInvoiceButton_Click(object sender, RoutedEventArgs e)
        {
            int invoiceID = -1;
            try
            {
                invoiceID = int.Parse(InvoiceIDTextBox.Text);
            }
            catch
            {
                //catch the error invoice ID and display to exit;
                MessageBox.Show("请输入正确的发票号！", "错误！", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            NewInovice newInvoice = new NewInovice(invoiceID);
            newInvoice.ShowDialog();
            //if there is no error, then to create a new invoice;
        }

        private void ViewInvoiceButton_Click(object sender, RoutedEventArgs e)
        {
            ViewInvoiceDialog viewInvoiceDialog = new ViewInvoiceDialog();
            viewInvoiceDialog.ShowDialog();
            //click to open the dialog to view the Invoice
        }

        private void materialsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            ERP_System.ERP_DBDataSet eRP_DBDataSet = ((ERP_System.ERP_DBDataSet)(this.FindResource("eRP_DBDataSet")));
            // 将数据加载到表 materials 中。可以根据需要修改此代码。
            ERP_System.ERP_DBDataSetTableAdapters.materialsTableAdapter eRP_DBDataSetmaterialsTableAdapter = new ERP_System.ERP_DBDataSetTableAdapters.materialsTableAdapter();
            eRP_DBDataSetmaterialsTableAdapter.Fill(eRP_DBDataSet.materials);
            System.Windows.Data.CollectionViewSource materialsViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("materialsViewSource")));
            materialsViewSource.View.MoveCurrentToFirst();
        }
        //reload material datagrid

    }
}
